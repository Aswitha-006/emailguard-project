import { ThreatLevel, IncidentStatus } from '@/data/mockData';

export function getThreatLevelColor(level: ThreatLevel | string): string {
  switch (level) {
    case 'Critical':
      return 'bg-red-100 text-red-700 border border-red-200';
    case 'High':
      return 'bg-orange-100 text-orange-700 border border-orange-200';
    case 'Medium':
      return 'bg-amber-100 text-amber-700 border border-amber-200';
    case 'Low':
      return 'bg-green-100 text-green-700 border border-green-200';
    default:
      return 'bg-gray-100 text-gray-700 border border-gray-200';
  }
}

export function getThreatLevelDot(level: ThreatLevel | string): string {
  switch (level) {
    case 'Critical':
      return 'bg-red-500';
    case 'High':
      return 'bg-orange-500';
    case 'Medium':
      return 'bg-amber-500';
    case 'Low':
      return 'bg-green-500';
    default:
      return 'bg-gray-500';
  }
}

export function getStatusColor(status: IncidentStatus | string): string {
  switch (status) {
    case 'New':
      return 'bg-blue-100 text-blue-700 border border-blue-200';
    case 'Investigating':
      return 'bg-accent-100 text-accent-700 border border-accent-200';
    case 'Escalated':
      return 'bg-red-100 text-red-700 border border-red-200';
    case 'Resolved':
      return 'bg-green-100 text-green-700 border border-green-200';
    default:
      return 'bg-gray-100 text-gray-700 border border-gray-200';
  }
}

export function getAuthResultColor(result: 'PASS' | 'FAIL' | 'NONE'): string {
  switch (result) {
    case 'PASS':
      return 'text-green-600 bg-green-50 border-green-200';
    case 'FAIL':
      return 'text-red-600 bg-red-50 border-red-200';
    case 'NONE':
      return 'text-gray-500 bg-gray-50 border-gray-200';
  }
}

export function getUrlClassificationColor(cls: string): string {
  switch (cls) {
    case 'Safe':
      return 'text-green-600 bg-green-50 border-green-200';
    case 'Suspicious':
      return 'text-amber-600 bg-amber-50 border-amber-200';
    case 'Malicious':
      return 'text-red-600 bg-red-50 border-red-200';
    default:
      return 'text-gray-600 bg-gray-50 border-gray-200';
  }
}
