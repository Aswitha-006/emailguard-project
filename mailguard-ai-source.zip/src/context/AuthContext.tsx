import { createContext, useContext, useState, ReactNode } from 'react';

export type Role = 'investigator' | 'client' | null;

interface AuthUser {
  role: Role;
  name: string;
  email: string;
  org: string;
}

interface AuthContextType {
  user: AuthUser | null;
  login: (role: Role, email: string, name?: string, org?: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);

  const login = (role: Role, email: string, name?: string, org?: string) => {
    if (!role) return;
    const orgName = org || (email.includes('globex') ? 'Globex Corp' : 'Acme Corp');
    const displayName = name || email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
    setUser({ role, email, name: displayName, org: orgName });
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
