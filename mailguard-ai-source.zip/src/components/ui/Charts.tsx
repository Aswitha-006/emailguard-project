import { incidents } from '@/data/mockData';

export function SeverityChart() {
  const levels = ['Critical', 'High', 'Medium', 'Low'] as const;
  const colors = ['bg-red-500', 'bg-orange-500', 'bg-amber-500', 'bg-green-500'];
  const counts = levels.map((l) => incidents.filter((i) => i.threatLevel === l).length);
  const max = Math.max(...counts, 1);

  return (
    <div className="space-y-3">
      {levels.map((level, i) => (
        <div key={level} className="flex items-center gap-3">
          <span className="text-sm font-medium text-cyber-text w-20">{level}</span>
          <div className="flex-1 h-7 bg-gray-50 rounded-lg overflow-hidden relative">
            <div
              className={`h-full ${colors[i]} rounded-lg transition-all duration-700 flex items-center justify-end pr-2`}
              style={{ width: `${(counts[i] / max) * 100}%` }}
            >
              <span className="text-xs font-bold text-white">{counts[i]}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export function SimpleThreatChart() {
  const types = ['Phishing', 'BEC', 'Impersonation', 'Suspicious', 'Malicious Email'] as const;
  const colors: Record<string, string> = {
    Phishing: 'bg-accent-500',
    BEC: 'bg-red-500',
    Impersonation: 'bg-orange-500',
    Suspicious: 'bg-amber-500',
    'Malicious Email': 'bg-pink-500',
  };
  const counts = types.map((t) => incidents.filter((i) => i.threatType === t).length);
  const max = Math.max(...counts, 1);

  return (
    <div className="space-y-3">
      {types.map((type, i) => (
        <div key={type} className="flex items-center gap-3">
          <span className="text-xs font-medium text-cyber-text w-28 truncate">{type}</span>
          <div className="flex-1 h-6 bg-gray-50 rounded-lg overflow-hidden">
            <div
              className={`h-full ${colors[type]} rounded-lg transition-all duration-700 flex items-center justify-end pr-2`}
              style={{ width: `${(counts[i] / max) * 100}%` }}
            >
              <span className="text-xs font-bold text-white">{counts[i]}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
