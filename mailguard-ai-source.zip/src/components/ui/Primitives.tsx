import { ReactNode } from 'react';

interface RiskGaugeProps {
  score: number;
  size?: 'sm' | 'md' | 'lg';
}

export function RiskGauge({ score, size = 'md' }: RiskGaugeProps) {
  const dimensions = {
    sm: { w: 80, h: 80, stroke: 6 },
    md: { w: 120, h: 120, stroke: 8 },
    lg: { w: 160, h: 160, stroke: 10 },
  };
  const { w, h, stroke } = dimensions[size];
  const radius = (w - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  const color = score >= 80 ? '#ef4444' : score >= 60 ? '#f97316' : score >= 40 ? '#f59e0b' : '#22c55e';

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: w, height: h }}>
      <svg width={w} height={h} className="-rotate-90">
        <circle cx={w / 2} cy={h / 2} r={radius} fill="none" stroke="#e9e7f0" strokeWidth={stroke} />
        <circle
          cx={w / 2}
          cy={h / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.8s ease-out' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className={`font-bold ${size === 'lg' ? 'text-3xl' : size === 'md' ? 'text-xl' : 'text-sm'}`} style={{ color }}>
          {score}
        </span>
        {size !== 'sm' && <span className="text-[10px] text-cyber-muted mt-0.5">RISK</span>}
      </div>
    </div>
  );
}

interface BadgeProps {
  children: ReactNode;
  className?: string;
}

export function Badge({ children, className = '' }: BadgeProps) {
  return <span className={`badge ${className}`}>{children}</span>;
}

interface ProgressBarProps {
  value: number;
  max?: number;
  label?: string;
  color?: string;
}

export function ProgressBar({ value, max = 100, label, color }: ProgressBarProps) {
  const percent = Math.min((value / max) * 100, 100);
  const barColor = color || (percent >= 80 ? 'bg-red-500' : percent >= 60 ? 'bg-orange-500' : percent >= 40 ? 'bg-amber-500' : 'bg-green-500');

  return (
    <div className="w-full">
      {label && (
        <div className="flex justify-between mb-1">
          <span className="text-sm text-cyber-muted">{label}</span>
          <span className="text-sm font-medium text-cyber-text">{value}{max === 100 ? '%' : ''}</span>
        </div>
      )}
      <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-700 ${barColor}`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}

interface ToastProps {
  message: string;
  visible: boolean;
}

export function Toast({ message, visible }: ToastProps) {
  if (!visible) return null;
  return (
    <div className="fixed bottom-6 right-6 z-50 animate-slide-up">
      <div className="bg-cyber-sidebar text-white px-5 py-3 rounded-xl shadow-lg flex items-center gap-2 border border-accent-600/30">
        <svg className="w-5 h-5 text-accent-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        {message}
      </div>
    </div>
  );
}
