export type ThreatType =
  | 'Phishing'
  | 'BEC'
  | 'Impersonation'
  | 'Malicious Email'
  | 'Suspicious'
  | 'Legitimate';

export type ThreatLevel = 'Critical' | 'High' | 'Medium' | 'Low';
export type IncidentStatus = 'New' | 'Investigating' | 'Escalated' | 'Resolved';
export type CaseStatus = 'New' | 'Investigating' | 'Escalated' | 'Resolved';

export interface UrlAnalysis {
  url: string;
  destinationDomain: string;
  classification: 'Safe' | 'Suspicious' | 'Malicious';
  lookalikePercent: number;
  domainReputation: string;
  hostingInfo: string;
}

export interface HeaderInfo {
  senderIP: string;
  receivedIPs: string[];
  mailRelay: string;
  asnIsp: string;
  hostname: string;
  ipReputation: string;
}

export interface RiskBreakdownItem {
  category: string;
  score: number;
  description: string;
}

export interface TraceNode {
  step: string;
  ip: string;
  hostname: string;
  ispAsn: string;
  country: string;
  city: string;
}

export interface Incident {
  id: string;
  senderName: string;
  senderEmail: string;
  recipientEmail: string;
  cc: string;
  replyTo: string;
  subject: string;
  dateTime: string;
  emailId: string;
  attachments: string[];
  emailBody: string;
  riskScore: number;
  threatLevel: ThreatLevel;
  threatType: ThreatType;
  status: IncidentStatus;
  clientOrg: string;
  aiConfidence: number;
  aiExplanation: string;
  suspiciousBehavior: string[];
  urgencyDetected: boolean;
  financialRequest: boolean;
  impersonationDetected: boolean;
  suspiciousLanguage: string[];
  secrecyManipulation: boolean;
  spf: 'PASS' | 'FAIL' | 'NONE';
  dkim: 'PASS' | 'FAIL' | 'NONE';
  dmarc: 'PASS' | 'FAIL' | 'NONE';
  senderDomain: string;
  replyToMismatch: boolean;
  displayNameSpoofing: boolean;
  domainSimilarityScore: number;
  urls: UrlAnalysis[];
  headerInfo: HeaderInfo;
  riskBreakdown: RiskBreakdownItem[];
  traceNodes: TraceNode[];
  clientExplanation: string;
  clientWhyFlagged: string[];
  actionTaken: string;
  recommendedAction: string;
  assignedInvestigator?: string;
  notes?: { author: string; text: string; date: string }[];
}

export interface Campaign {
  id: string;
  name: string;
  incidentIds: string[];
  commonSenderDomain: string;
  commonUrl: string;
  firstDetected: string;
  lastDetected: string;
  severity: ThreatLevel;
}

export interface Case {
  id: string;
  incidentId: string;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  assignedInvestigator: string;
  status: CaseStatus;
  createdDate: string;
  lastUpdated: string;
}

export interface Report {
  id: string;
  caseId: string;
  incidentId: string;
  title: string;
  generatedDate: string;
  attributionConfidence: number;
}

export const incidents: Incident[] = [
  {
    id: 'INC-2024-001',
    senderName: 'David Chen',
    senderEmail: 'd.chen@c0mpany-exec.com',
    recipientEmail: 'finance@acmecorp.com',
    cc: 'cfo@acmecorp.com',
    replyTo: 'david.chen@exec-mail.net',
    subject: 'Urgent: Wire Transfer Approval Required — $47,500',
    dateTime: '2024-09-03 14:23:11 UTC',
    emailId: 'MSG-9f3a2b1c@example.com',
    attachments: ['Wire_Transfer_Details.pdf'],
    emailBody:
      'Hi team,\n\nI need you to process an urgent wire transfer of $47,500 to the attached account details immediately. This is time-sensitive and confidential — please do not discuss with anyone else. I am in meetings all day and cannot be reached by phone.\n\nRegards,\nDavid Chen\nCFO',
    riskScore: 94,
    threatLevel: 'Critical',
    threatType: 'BEC',
    status: 'New',
    clientOrg: 'Acme Corp',
    aiConfidence: 96,
    aiExplanation:
      'This email appears suspicious because it creates urgency, requests a financial action, and uses an executive-like identity. The sender domain is a lookalike of the legitimate company domain, and the reply-to address differs from the sender address.',
    suspiciousBehavior: [
      'Executive impersonation with financial request',
      'Urgency and secrecy language pattern',
      'Reply-to domain mismatch',
      'Lookalike sender domain',
    ],
    urgencyDetected: true,
    financialRequest: true,
    impersonationDetected: true,
    suspiciousLanguage: [
      'urgent',
      'immediately',
      'time-sensitive',
      'do not discuss',
      'cannot be reached',
    ],
    secrecyManipulation: true,
    spf: 'FAIL',
    dkim: 'FAIL',
    dmarc: 'FAIL',
    senderDomain: 'c0mpany-exec.com',
    replyToMismatch: true,
    displayNameSpoofing: true,
    domainSimilarityScore: 87,
    urls: [
      {
        url: 'https://c0mpany-exec.com/transfer/confirm',
        destinationDomain: 'c0mpany-exec.com',
        classification: 'Malicious',
        lookalikePercent: 87,
        domainReputation: 'Poor — Recently registered',
        hostingInfo: 'Shared hosting, Bulgaria',
      },
    ],
    headerInfo: {
      senderIP: '185.234.12.89',
      receivedIPs: ['185.234.12.89', '10.0.1.22', '172.16.8.4'],
      mailRelay: 'mx1.c0mpany-exec.com',
      asnIsp: 'AS204957 — Bulgarian Telecom Ltd.',
      hostname: 'smtp01.c0mpany-exec.com',
      ipReputation: 'Malicious — Known spam source',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 22, description: 'SPF/DKIM/DMARC all failed; reply-to mismatch' },
      { category: 'AI/NLP Analysis', score: 25, description: 'Urgency, financial request, secrecy language' },
      { category: 'URL Analysis', score: 18, description: 'Lookalike domain with 87% similarity' },
      { category: 'Domain Reputation', score: 15, description: 'Recently registered, poor reputation' },
      { category: 'Impersonation Detection', score: 14, description: 'Executive name spoofing detected' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '185.234.12.89', hostname: 'smtp01.c0mpany-exec.com', ispAsn: 'AS204957', country: 'Bulgaria', city: 'Sofia' },
      { step: 'Mail Relay', ip: '185.234.12.90', hostname: 'mx1.c0mpany-exec.com', ispAsn: 'AS204957', country: 'Bulgaria', city: 'Sofia' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '185.234.12.89', hostname: 'bg-telecom.net', ispAsn: 'AS204957 — Bulgarian Telecom', country: 'Bulgaria', city: 'Sofia' },
      { step: 'Probable Infrastructure Location', ip: '185.234.12.89', hostname: 'smtp01.c0mpany-exec.com', ispAsn: 'AS204957', country: 'Bulgaria', city: 'Sofia' },
    ],
    clientExplanation:
      'A suspicious email was detected pretending to be from your CFO David Chen, asking for an urgent wire transfer of $47,500. The sender used a fake domain that looks similar to your company domain.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — the email address was a lookalike domain',
      'Email requested an urgent financial wire transfer',
      'Message created unusual urgency and asked for secrecy',
      'Domain looked similar to a trusted company domain',
    ],
    actionTaken: 'Email blocked',
    recommendedAction: 'Do not click links or provide payment information. Verify any wire transfer requests by phone with the known CFO.',
  },
  {
    id: 'INC-2024-002',
    senderName: 'Microsoft Security',
    senderEmail: 'no-reply@micros0ft-secure.com',
    recipientEmail: 'j.allen@acmecorp.com',
    cc: '',
    replyTo: 'support@micros0ft-secure.com',
    subject: 'Your account has been compromised — Verify now',
    dateTime: '2024-09-03 11:45:02 UTC',
    emailId: 'MSG-7d2e1a9b@example.com',
    attachments: [],
    emailBody:
      'Dear User,\n\nWe have detected unusual activity on your Microsoft account. Your account will be suspended within 24 hours unless you verify your identity immediately.\n\nClick here to verify: https://micros0ft-secure.com/verify\n\nMicrosoft Security Team',
    riskScore: 88,
    threatLevel: 'Critical',
    threatType: 'Phishing',
    status: 'Investigating',
    clientOrg: 'Acme Corp',
    aiConfidence: 93,
    aiExplanation:
      'This email is a classic phishing attempt. It uses a lookalike Microsoft domain, creates false urgency about account suspension, and directs the user to a fraudulent verification page.',
    suspiciousBehavior: [
      'Brand impersonation (Microsoft)',
      'Account suspension urgency tactic',
      'Lookalike domain with zero substitution',
      'Credential harvesting link',
    ],
    urgencyDetected: true,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: ['compromised', 'suspended', '24 hours', 'verify immediately'],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'NONE',
    dmarc: 'FAIL',
    senderDomain: 'micros0ft-secure.com',
    replyToMismatch: true,
    displayNameSpoofing: true,
    domainSimilarityScore: 91,
    urls: [
      {
        url: 'https://micros0ft-secure.com/verify',
        destinationDomain: 'micros0ft-secure.com',
        classification: 'Malicious',
        lookalikePercent: 91,
        domainReputation: 'Poor — Typosquatting domain',
        hostingInfo: 'Shared hosting, Russia',
      },
    ],
    headerInfo: {
      senderIP: '194.58.88.12',
      receivedIPs: ['194.58.88.12', '10.0.1.22'],
      mailRelay: 'mail.micros0ft-secure.com',
      asnIsp: 'AS49505 — Selectel Network',
      hostname: 'node12.micros0ft-secure.com',
      ipReputation: 'Malicious — Known phishing infrastructure',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 20, description: 'SPF failed, DMARC failed, reply-to mismatch' },
      { category: 'AI/NLP Analysis', score: 22, description: 'Urgency, credential harvesting language' },
      { category: 'URL Analysis', score: 20, description: 'Typosquatting domain, 91% similarity' },
      { category: 'Domain Reputation', score: 14, description: 'Poor reputation, recently registered' },
      { category: 'Impersonation Detection', score: 12, description: 'Microsoft brand spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '194.58.88.12', hostname: 'node12.micros0ft-secure.com', ispAsn: 'AS49505', country: 'Russia', city: 'Moscow' },
      { step: 'Mail Relay', ip: '194.58.88.15', hostname: 'mail.micros0ft-secure.com', ispAsn: 'AS49505', country: 'Russia', city: 'Moscow' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '194.58.88.12', hostname: 'selectel.net', ispAsn: 'AS49505 — Selectel', country: 'Russia', city: 'Moscow' },
      { step: 'Probable Infrastructure Location', ip: '194.58.88.12', hostname: 'node12.micros0ft-secure.com', ispAsn: 'AS49505', country: 'Russia', city: 'Moscow' },
    ],
    clientExplanation:
      'A phishing email pretending to be from Microsoft Security was detected. It claimed your account was compromised and tried to get you to click a fake verification link.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake Microsoft domain',
      'Email contained a suspicious link to a fake verification page',
      'Message created unusual urgency about account suspension',
      'Domain looked similar to the real Microsoft domain',
    ],
    actionTaken: 'Email quarantined',
    recommendedAction: 'Do not click links or provide any account credentials. Microsoft will never ask you to verify via email links.',
  },
  {
    id: 'INC-2024-003',
    senderName: 'Sarah Johnson',
    senderEmail: 's.johnson@gmaill.com',
    recipientEmail: 'ops@globex.com',
    cc: 'manager@globex.com',
    replyTo: 'sarah.j@personal-mail.org',
    subject: 'Invoice #2847 — Payment Due',
    dateTime: '2024-09-02 09:15:33 UTC',
    emailId: 'MSG-3c8f7d2e@example.com',
    attachments: ['Invoice_2847.zip'],
    emailBody:
      'Hello,\n\nPlease find attached invoice #2847 for services rendered. Payment is due within 5 business days. Kindly open the attached file for details.\n\nBest regards,\nSarah Johnson\nAccounts Team',
    riskScore: 72,
    threatLevel: 'High',
    threatType: 'Malicious Email',
    status: 'Investigating',
    clientOrg: 'Globex Corp',
    aiConfidence: 85,
    aiExplanation:
      'This email contains a malicious ZIP attachment likely harboring malware. The sender domain is a typosquatting variant of gmail.com, and the reply-to address differs from the sender.',
    suspiciousBehavior: [
      'Malicious ZIP attachment',
      'Typosquatting domain (gmaill.com)',
      'Reply-to mismatch',
      'Generic invoice lure',
    ],
    urgencyDetected: false,
    financialRequest: true,
    impersonationDetected: false,
    suspiciousLanguage: ['payment due', '5 business days', 'open the attached file'],
    secrecyManipulation: false,
    spf: 'NONE',
    dkim: 'FAIL',
    dmarc: 'FAIL',
    senderDomain: 'gmaill.com',
    replyToMismatch: true,
    displayNameSpoofing: false,
    domainSimilarityScore: 83,
    urls: [],
    headerInfo: {
      senderIP: '45.142.22.10',
      receivedIPs: ['45.142.22.10', '172.16.4.1'],
      mailRelay: 'smtp.gmaill.com',
      asnIsp: 'AS39772 — FlokiNET',
      hostname: 'mail01.gmaill.com',
      ipReputation: 'Suspicious — Known malware distribution',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 16, description: 'DKIM failed, DMARC failed, reply-to mismatch' },
      { category: 'AI/NLP Analysis', score: 14, description: 'Invoice lure with attachment prompt' },
      { category: 'URL Analysis', score: 8, description: 'No URLs but malicious attachment' },
      { category: 'Domain Reputation', score: 18, description: 'Typosquatting domain, suspicious hosting' },
      { category: 'Impersonation Detection', score: 16, description: 'Gmail brand typosquatting' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '45.142.22.10', hostname: 'mail01.gmaill.com', ispAsn: 'AS39772', country: 'Romania', city: 'Bucharest' },
      { step: 'Mail Relay', ip: '45.142.22.14', hostname: 'smtp.gmaill.com', ispAsn: 'AS39772', country: 'Romania', city: 'Bucharest' },
      { step: 'Mail Server', ip: '172.16.4.1', hostname: 'mail.globex.com', ispAsn: 'Internal', country: 'United States', city: 'San Francisco' },
      { step: 'ISP/ASN', ip: '45.142.22.10', hostname: 'flokinet.ro', ispAsn: 'AS39772 — FlokiNET', country: 'Romania', city: 'Bucharest' },
      { step: 'Probable Infrastructure Location', ip: '45.142.22.10', hostname: 'mail01.gmaill.com', ispAsn: 'AS39772', country: 'Romania', city: 'Bucharest' },
    ],
    clientExplanation:
      'A suspicious email with a fake invoice was detected. It contained a ZIP attachment that could contain harmful software. The sender used a fake Gmail-like email address.',
    clientWhyFlagged: [
      'Email contained a suspicious attachment (ZIP file)',
      'Sender email was a lookalike of a Gmail address',
      'Domain looked similar to a trusted email provider',
    ],
    actionTaken: 'Email quarantined',
    recommendedAction: 'Do not open the attachment. Delete the email and report it to your IT team.',
  },
  {
    id: 'INC-2024-004',
    senderName: 'CEO Robert Williams',
    senderEmail: 'rwilliams@acme-corp.net',
    recipientEmail: 'ap@acmecorp.com',
    cc: '',
    replyTo: 'r.williams.private@protonmail.ch',
    subject: 'Re: Gift Cards for Clients — Need ASAP',
    dateTime: '2024-09-02 16:30:00 UTC',
    emailId: 'MSG-5a1b3c4d@example.com',
    attachments: [],
    emailBody:
      'Hi,\n\nI need you to purchase $2,000 in Apple gift cards for our top clients today. This is urgent — I have a meeting in 10 minutes. Please send the card numbers to me as soon as you get them. Keep this between us.\n\nRobert',
    riskScore: 91,
    threatLevel: 'Critical',
    threatType: 'Impersonation',
    status: 'Escalated',
    clientOrg: 'Acme Corp',
    aiConfidence: 95,
    aiExplanation:
      'This is a classic gift card scam impersonating the CEO. The email creates extreme urgency, requests gift card purchases, uses a protonmail reply-to address, and asks for secrecy.',
    suspiciousBehavior: [
      'CEO impersonation',
      'Gift card scam pattern',
      'Reply-to to personal email (ProtonMail)',
      'Secrecy request',
      'Extreme urgency',
    ],
    urgencyDetected: true,
    financialRequest: true,
    impersonationDetected: true,
    suspiciousLanguage: ['urgent', 'ASAP', 'keep this between us', '10 minutes'],
    secrecyManipulation: true,
    spf: 'NONE',
    dkim: 'NONE',
    dmarc: 'FAIL',
    senderDomain: 'acme-corp.net',
    replyToMismatch: true,
    displayNameSpoofing: true,
    domainSimilarityScore: 79,
    urls: [],
    headerInfo: {
      senderIP: '91.214.124.55',
      receivedIPs: ['91.214.124.55', '10.0.1.22'],
      mailRelay: 'smtp.acme-corp.net',
      asnIsp: 'AS197595 — Green Floid LLC',
      hostname: 'relay55.acme-corp.net',
      ipReputation: 'Suspicious — Bullet-proof hosting',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 20, description: 'DMARC failed, reply-to to ProtonMail' },
      { category: 'AI/NLP Analysis', score: 25, description: 'Gift card scam, urgency, secrecy' },
      { category: 'URL Analysis', score: 5, description: 'No URLs present' },
      { category: 'Domain Reputation', score: 20, description: 'Lookalike domain, bullet-proof hosting' },
      { category: 'Impersonation Detection', score: 21, description: 'CEO name and title spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '91.214.124.55', hostname: 'relay55.acme-corp.net', ispAsn: 'AS197595', country: 'Seychelles', city: 'Victoria' },
      { step: 'Mail Relay', ip: '91.214.124.60', hostname: 'smtp.acme-corp.net', ispAsn: 'AS197595', country: 'Seychelles', city: 'Victoria' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '91.214.124.55', hostname: 'greenfloid.net', ispAsn: 'AS197595 — Green Floid', country: 'Seychelles', city: 'Victoria' },
      { step: 'Probable Infrastructure Location', ip: '91.214.124.55', hostname: 'relay55.acme-corp.net', ispAsn: 'AS197595', country: 'Seychelles', city: 'Victoria' },
    ],
    clientExplanation:
      'Someone impersonating your CEO Robert Williams asked an employee to urgently purchase $2,000 in gift cards and send the card numbers privately. This is a well-known scam pattern.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — impersonating the CEO',
      'Email requested urgent purchase of gift cards',
      'Message created unusual urgency',
      'Sender asked for secrecy',
    ],
    actionTaken: 'Email blocked',
    recommendedAction: 'Do not purchase gift cards based on email requests. Verify with the CEO by phone using the known company number.',
  },
  {
    id: 'INC-2024-005',
    senderName: 'IT Helpdesk',
    senderEmail: 'helpdesk@acme-portal.com',
    recipientEmail: 'all-staff@acmecorp.com',
    cc: '',
    replyTo: 'admin@acme-portal.com',
    subject: 'Password Reset Required — Security Alert',
    dateTime: '2024-09-02 08:00:17 UTC',
    emailId: 'MSG-2e9f8a7b@example.com',
    attachments: [],
    emailBody:
      'Dear Employee,\n\nYour password is about to expire. Please reset your password immediately by visiting: https://acme-portal.com/reset?session=abc123\n\nFailure to do so will result in account lockout.\n\nIT Helpdesk',
    riskScore: 76,
    threatLevel: 'High',
    threatType: 'Phishing',
    status: 'Investigating',
    clientOrg: 'Acme Corp',
    aiConfidence: 88,
    aiExplanation:
      'This email impersonates the internal IT helpdesk using a lookalike domain. The password reset link directs to a fraudulent page designed to steal credentials.',
    suspiciousBehavior: [
      'IT helpdesk impersonation',
      'Credential harvesting via fake reset link',
      'Lookalike domain (acme-portal.com vs acmecorp.com)',
      'Threat of account lockout',
    ],
    urgencyDetected: true,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: ['immediately', 'failure to do so', 'account lockout'],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'FAIL',
    dmarc: 'FAIL',
    senderDomain: 'acme-portal.com',
    replyToMismatch: false,
    displayNameSpoofing: true,
    domainSimilarityScore: 74,
    urls: [
      {
        url: 'https://acme-portal.com/reset?session=abc123',
        destinationDomain: 'acme-portal.com',
        classification: 'Malicious',
        lookalikePercent: 74,
        domainReputation: 'Poor — Lookalike domain',
        hostingInfo: 'VPS, Netherlands',
      },
    ],
    headerInfo: {
      senderIP: '89.248.165.20',
      receivedIPs: ['89.248.165.20', '10.0.1.22'],
      mailRelay: 'mx.acme-portal.com',
      asnIsp: 'AS29073 — Ecatel Network',
      hostname: 'vps20.acme-portal.com',
      ipReputation: 'Suspicious — Known phishing host',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 20, description: 'All auth checks failed' },
      { category: 'AI/NLP Analysis', score: 18, description: 'Urgency, credential harvesting' },
      { category: 'URL Analysis', score: 18, description: 'Lookalike domain, 74% similarity' },
      { category: 'Domain Reputation', score: 12, description: 'Poor reputation VPS' },
      { category: 'Impersonation Detection', score: 8, description: 'IT helpdesk spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '89.248.165.20', hostname: 'vps20.acme-portal.com', ispAsn: 'AS29073', country: 'Netherlands', city: 'Amsterdam' },
      { step: 'Mail Relay', ip: '89.248.165.25', hostname: 'mx.acme-portal.com', ispAsn: 'AS29073', country: 'Netherlands', city: 'Amsterdam' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '89.248.165.20', hostname: 'ecatel.net', ispAsn: 'AS29073 — Ecatel', country: 'Netherlands', city: 'Amsterdam' },
      { step: 'Probable Infrastructure Location', ip: '89.248.165.20', hostname: 'vps20.acme-portal.com', ispAsn: 'AS29073', country: 'Netherlands', city: 'Amsterdam' },
    ],
    clientExplanation:
      'A fake IT helpdesk email was detected trying to trick employees into entering their password on a fake password reset page. The sender used a domain that looks like your company portal.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake IT helpdesk',
      'Email contained a suspicious link to a fake password reset page',
      'Message created unusual urgency about account lockout',
      'Domain looked similar to your company portal',
    ],
    actionTaken: 'Email blocked',
    recommendedAction: 'Do not click the link or enter your password. Your IT team will never ask you to reset your password via an email link.',
  },
  {
    id: 'INC-2024-006',
    senderName: 'LinkedIn',
    senderEmail: 'invitations@linkedin-secure.com',
    recipientEmail: 'j.allen@acmecorp.com',
    cc: '',
    replyTo: '',
    subject: 'You have 3 new connection requests',
    dateTime: '2024-09-01 22:14:50 UTC',
    emailId: 'MSG-1a2b3c4e@example.com',
    attachments: [],
    emailBody:
      'Hi James,\n\nYou have 3 new connection requests waiting. View them here: https://linkedin-secure.com/connections\n\nLinkedIn Team',
    riskScore: 61,
    threatLevel: 'Medium',
    threatType: 'Phishing',
    status: 'New',
    clientOrg: 'Acme Corp',
    aiConfidence: 82,
    aiExplanation:
      'This email impersonates LinkedIn using a lookalike domain. The connection requests lure is designed to direct users to a credential harvesting page.',
    suspiciousBehavior: [
      'LinkedIn brand impersonation',
      'Lookalike domain (linkedin-secure.com)',
      'Credential harvesting link',
    ],
    urgencyDetected: false,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: ['new connection requests waiting'],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'NONE',
    dmarc: 'FAIL',
    senderDomain: 'linkedin-secure.com',
    replyToMismatch: false,
    displayNameSpoofing: true,
    domainSimilarityScore: 68,
    urls: [
      {
        url: 'https://linkedin-secure.com/connections',
        destinationDomain: 'linkedin-secure.com',
        classification: 'Suspicious',
        lookalikePercent: 68,
        domainReputation: 'Poor — Lookalike domain',
        hostingInfo: 'Shared hosting, Panama',
      },
    ],
    headerInfo: {
      senderIP: '190.34.12.88',
      receivedIPs: ['190.34.12.88', '10.0.1.22'],
      mailRelay: 'mail.linkedin-secure.com',
      asnIsp: 'AS262287 — Panama Hosting',
      hostname: 'srv88.linkedin-secure.com',
      ipReputation: 'Suspicious — Lookalike hosting',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 14, description: 'SPF failed, DMARC failed' },
      { category: 'AI/NLP Analysis', score: 10, description: 'Connection request lure' },
      { category: 'URL Analysis', score: 16, description: 'Lookalike domain, 68% similarity' },
      { category: 'Domain Reputation', score: 12, description: 'Poor reputation shared hosting' },
      { category: 'Impersonation Detection', score: 9, description: 'LinkedIn brand spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '190.34.12.88', hostname: 'srv88.linkedin-secure.com', ispAsn: 'AS262287', country: 'Panama', city: 'Panama City' },
      { step: 'Mail Relay', ip: '190.34.12.90', hostname: 'mail.linkedin-secure.com', ispAsn: 'AS262287', country: 'Panama', city: 'Panama City' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '190.34.12.88', hostname: 'panamahost.com', ispAsn: 'AS262287 — Panama Hosting', country: 'Panama', city: 'Panama City' },
      { step: 'Probable Infrastructure Location', ip: '190.34.12.88', hostname: 'srv88.linkedin-secure.com', ispAsn: 'AS262287', country: 'Panama', city: 'Panama City' },
    ],
    clientExplanation:
      'A fake LinkedIn email was detected claiming you have new connection requests. The link in the email goes to a fake LinkedIn page that could steal your login.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake LinkedIn domain',
      'Email contained a suspicious link',
      'Domain looked similar to the real LinkedIn domain',
    ],
    actionTaken: 'Email marked suspicious',
    recommendedAction: 'Do not click the link. If you want to check your LinkedIn connections, go directly to linkedin.com in your browser.',
  },
  {
    id: 'INC-2024-007',
    senderName: 'Amazon',
    senderEmail: 'orders@arnazon.com',
    recipientEmail: 'j.allen@acmecorp.com',
    cc: '',
    replyTo: '',
    subject: 'Your Amazon order #112-8874231 has shipped',
    dateTime: '2024-09-01 15:22:08 UTC',
    emailId: 'MSG-6b5a4c3d@example.com',
    attachments: [],
    emailBody:
      'Hello,\n\nYour Amazon order #112-8874231 has shipped. Track your package here: https://arnazon.com/track/112-8874231\n\nAmazon.com',
    riskScore: 58,
    threatLevel: 'Medium',
    threatType: 'Suspicious',
    status: 'New',
    clientOrg: 'Acme Corp',
    aiConfidence: 79,
    aiExplanation:
      'This email uses a typosquatting domain (arnazon.com instead of amazon.com) with an r/n substitution. While the content appears benign, the domain is suspicious.',
    suspiciousBehavior: [
      'Amazon brand typosquatting (r/n substitution)',
      'Tracking link to lookalike domain',
    ],
    urgencyDetected: false,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: [],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'NONE',
    dmarc: 'NONE',
    senderDomain: 'arnazon.com',
    replyToMismatch: false,
    displayNameSpoofing: true,
    domainSimilarityScore: 72,
    urls: [
      {
        url: 'https://arnazon.com/track/112-8874231',
        destinationDomain: 'arnazon.com',
        classification: 'Suspicious',
        lookalikePercent: 72,
        domainReputation: 'Suspicious — Typosquatting',
        hostingInfo: 'CDN, United States',
      },
    ],
    headerInfo: {
      senderIP: '104.28.16.55',
      receivedIPs: ['104.28.16.55', '10.0.1.22'],
      mailRelay: 'mail.arnazon.com',
      asnIsp: 'AS13335 — Cloudflare',
      hostname: 'cdn55.arnazon.com',
      ipReputation: 'Suspicious — Typosquatting behind CDN',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 12, description: 'SPF failed, no DMARC record' },
      { category: 'AI/NLP Analysis', score: 6, description: 'Standard order notification language' },
      { category: 'URL Analysis', score: 16, description: 'Typosquatting domain, 72% similarity' },
      { category: 'Domain Reputation', score: 14, description: 'Suspicious, behind CDN' },
      { category: 'Impersonation Detection', score: 10, description: 'Amazon brand typosquatting' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '104.28.16.55', hostname: 'cdn55.arnazon.com', ispAsn: 'AS13335', country: 'United States', city: 'San Francisco' },
      { step: 'Mail Relay', ip: '104.28.16.60', hostname: 'mail.arnazon.com', ispAsn: 'AS13335', country: 'United States', city: 'San Francisco' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '104.28.16.55', hostname: 'cloudflare.com', ispAsn: 'AS13335 — Cloudflare', country: 'United States', city: 'San Francisco' },
      { step: 'Probable Infrastructure Location', ip: '104.28.16.55', hostname: 'cdn55.arnazon.com', ispAsn: 'AS13335', country: 'United States', city: 'San Francisco' },
    ],
    clientExplanation:
      'A suspicious email pretending to be from Amazon was detected. It used a fake Amazon web address (arnazon.com instead of amazon.com) that could lead to a fake website.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake Amazon domain',
      'Email contained a suspicious tracking link',
      'Domain looked similar to the real Amazon domain',
    ],
    actionTaken: 'Email marked suspicious',
    recommendedAction: 'Do not click the tracking link. Check your orders directly on amazon.com.',
  },
  {
    id: 'INC-2024-008',
    senderName: 'HR Department',
    senderEmail: 'hr@acme-hrportal.com',
    recipientEmail: 'all-staff@acmecorp.com',
    cc: '',
    replyTo: 'hr.update@external-hr.net',
    subject: 'Updated Employee Handbook — Please Review',
    dateTime: '2024-08-31 11:30:00 UTC',
    emailId: 'MSG-8c7d6e5f@example.com',
    attachments: ['Employee_Handbook_2024.pdf'],
    emailBody:
      'Dear Team,\n\nPlease review the updated employee handbook attached to this email. All employees must acknowledge receipt by Friday.\n\nHR Department',
    riskScore: 45,
    threatLevel: 'Medium',
    threatType: 'Suspicious',
    status: 'Resolved',
    clientOrg: 'Acme Corp',
    aiConfidence: 71,
    aiExplanation:
      'This email uses a lookalike HR portal domain and has a reply-to mismatch. While the content is benign, the domain and reply-to inconsistency warrant caution.',
    suspiciousBehavior: [
      'Lookalike HR domain',
      'Reply-to mismatch',
      'Attachment from external source',
    ],
    urgencyDetected: false,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: ['must acknowledge', 'by Friday'],
    secrecyManipulation: false,
    spf: 'NONE',
    dkim: 'PASS',
    dmarc: 'NONE',
    senderDomain: 'acme-hrportal.com',
    replyToMismatch: true,
    displayNameSpoofing: true,
    domainSimilarityScore: 61,
    urls: [],
    headerInfo: {
      senderIP: '203.0.113.45',
      receivedIPs: ['203.0.113.45', '10.0.1.22'],
      mailRelay: 'mail.acme-hrportal.com',
      asnIsp: 'AS16509 — Amazon AWS',
      hostname: 'ec2-45.acme-hrportal.com',
      ipReputation: 'Neutral — Cloud hosting',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 10, description: 'DKIM passed but reply-to mismatch' },
      { category: 'AI/NLP Analysis', score: 6, description: 'Standard HR communication' },
      { category: 'URL Analysis', score: 0, description: 'No URLs present' },
      { category: 'Domain Reputation', score: 14, description: 'Lookalike domain on cloud host' },
      { category: 'Impersonation Detection', score: 15, description: 'HR department spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '203.0.113.45', hostname: 'ec2-45.acme-hrportal.com', ispAsn: 'AS16509', country: 'United States', city: 'Ashburn' },
      { step: 'Mail Relay', ip: '203.0.113.50', hostname: 'mail.acme-hrportal.com', ispAsn: 'AS16509', country: 'United States', city: 'Ashburn' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '203.0.113.45', hostname: 'aws.amazon.com', ispAsn: 'AS16509 — Amazon AWS', country: 'United States', city: 'Ashburn' },
      { step: 'Probable Infrastructure Location', ip: '203.0.113.45', hostname: 'ec2-45.acme-hrportal.com', ispAsn: 'AS16509', country: 'United States', city: 'Ashburn' },
    ],
    clientExplanation:
      'A suspicious email pretending to be from your HR department was detected. It asked employees to review an attached handbook, but the sender used a fake HR website address.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake HR domain',
      'Email contained an attachment from an external source',
      'Domain looked similar to your company domain',
    ],
    actionTaken: 'Email quarantined',
    recommendedAction: 'Do not open the attachment. Verify with your HR team directly before reviewing any handbook.',
  },
  {
    id: 'INC-2024-009',
    senderName: 'FedEx Shipping',
    senderEmail: 'tracking@fedex-ship.net',
    recipientEmail: 'ops@globex.com',
    cc: '',
    replyTo: '',
    subject: 'Package Delivery Failed — Reschedule',
    dateTime: '2024-08-31 09:45:22 UTC',
    emailId: 'MSG-4d3c2b1a@example.com',
    attachments: [],
    emailBody:
      'Dear Customer,\n\nWe attempted to deliver your package but no one was available. Please reschedule delivery here: https://fedex-ship.net/reschedule?id=XYZ789\n\nFedEx',
    riskScore: 67,
    threatLevel: 'High',
    threatType: 'Phishing',
    status: 'Investigating',
    clientOrg: 'Globex Corp',
    aiConfidence: 84,
    aiExplanation:
      'This email impersonates FedEx using a lookalike domain. The failed delivery lure is a common phishing tactic to collect personal information or deliver malware.',
    suspiciousBehavior: [
      'FedEx brand impersonation',
      'Lookalike domain (fedex-ship.net)',
      'Failed delivery lure',
      'Personal information collection',
    ],
    urgencyDetected: true,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: ['delivery failed', 'reschedule'],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'FAIL',
    dmarc: 'FAIL',
    senderDomain: 'fedex-ship.net',
    replyToMismatch: false,
    displayNameSpoofing: true,
    domainSimilarityScore: 70,
    urls: [
      {
        url: 'https://fedex-ship.net/reschedule?id=XYZ789',
        destinationDomain: 'fedex-ship.net',
        classification: 'Malicious',
        lookalikePercent: 70,
        domainReputation: 'Poor — Phishing domain',
        hostingInfo: 'Shared hosting, Turkey',
      },
    ],
    headerInfo: {
      senderIP: '31.14.22.100',
      receivedIPs: ['31.14.22.100', '172.16.4.1'],
      mailRelay: 'smtp.fedex-ship.net',
      asnIsp: 'AS57866 — Milesight',
      hostname: 'mail100.fedex-ship.net',
      ipReputation: 'Malicious — Known phishing source',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 18, description: 'All auth checks failed' },
      { category: 'AI/NLP Analysis', score: 14, description: 'Failed delivery phishing lure' },
      { category: 'URL Analysis', score: 17, description: 'Lookalike domain, 70% similarity' },
      { category: 'Domain Reputation', score: 12, description: 'Poor reputation, phishing host' },
      { category: 'Impersonation Detection', score: 6, description: 'FedEx brand spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '31.14.22.100', hostname: 'mail100.fedex-ship.net', ispAsn: 'AS57866', country: 'Turkey', city: 'Istanbul' },
      { step: 'Mail Relay', ip: '31.14.22.110', hostname: 'smtp.fedex-ship.net', ispAsn: 'AS57866', country: 'Turkey', city: 'Istanbul' },
      { step: 'Mail Server', ip: '172.16.4.1', hostname: 'mail.globex.com', ispAsn: 'Internal', country: 'United States', city: 'San Francisco' },
      { step: 'ISP/ASN', ip: '31.14.22.100', hostname: 'milesight.net', ispAsn: 'AS57866 — Milesight', country: 'Turkey', city: 'Istanbul' },
      { step: 'Probable Infrastructure Location', ip: '31.14.22.100', hostname: 'mail100.fedex-ship.net', ispAsn: 'AS57866', country: 'Turkey', city: 'Istanbul' },
    ],
    clientExplanation:
      'A fake FedEx email was detected claiming a package delivery failed. The link in the email goes to a fake FedEx page that could steal your personal information.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake FedEx domain',
      'Email contained a suspicious link',
      'Domain looked similar to the real FedEx domain',
    ],
    actionTaken: 'Email blocked',
    recommendedAction: 'Do not click the link. If you are expecting a package, check the tracking number directly on fedex.com.',
  },
  {
    id: 'INC-2024-010',
    senderName: 'Google Security Alert',
    senderEmail: 'alert@goog1e-accounts.com',
    recipientEmail: 'j.allen@acmecorp.com',
    cc: '',
    replyTo: '',
    subject: 'Suspicious login attempt on your Google account',
    dateTime: '2024-08-30 18:00:00 UTC',
    emailId: 'MSG-9e8d7c6b@example.com',
    attachments: [],
    emailBody:
      'Hi,\n\nWe detected a suspicious login attempt on your Google account from Lagos, Nigeria. If this was not you, please secure your account: https://goog1e-accounts.com/secure\n\nGoogle Security',
    riskScore: 70,
    threatLevel: 'High',
    threatType: 'Phishing',
    status: 'Resolved',
    clientOrg: 'Acme Corp',
    aiConfidence: 87,
    aiExplanation:
      'This email uses a typosquatting domain (goog1e-accounts.com with l/1 substitution) to impersonate Google. The security alert lure directs to a credential harvesting page.',
    suspiciousBehavior: [
      'Google brand typosquatting (l/1 substitution)',
      'Security alert phishing lure',
      'Credential harvesting link',
    ],
    urgencyDetected: true,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: ['suspicious login', 'if this was not you', 'secure your account'],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'NONE',
    dmarc: 'FAIL',
    senderDomain: 'goog1e-accounts.com',
    replyToMismatch: false,
    displayNameSpoofing: true,
    domainSimilarityScore: 85,
    urls: [
      {
        url: 'https://goog1e-accounts.com/secure',
        destinationDomain: 'goog1e-accounts.com',
        classification: 'Malicious',
        lookalikePercent: 85,
        domainReputation: 'Poor — Typosquatting domain',
        hostingInfo: 'VPS, Nigeria',
      },
    ],
    headerInfo: {
      senderIP: '41.58.12.77',
      receivedIPs: ['41.58.12.77', '10.0.1.22'],
      mailRelay: 'mail.goog1e-accounts.com',
      asnIsp: 'AS37061 — Globacom',
      hostname: 'srv77.goog1e-accounts.com',
      ipReputation: 'Malicious — Known phishing source',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 18, description: 'SPF failed, DMARC failed' },
      { category: 'AI/NLP Analysis', score: 16, description: 'Security alert urgency, credential harvesting' },
      { category: 'URL Analysis', score: 18, description: 'Typosquatting, 85% similarity' },
      { category: 'Domain Reputation', score: 12, description: 'Poor reputation, Nigerian hosting' },
      { category: 'Impersonation Detection', score: 6, description: 'Google brand typosquatting' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '41.58.12.77', hostname: 'srv77.goog1e-accounts.com', ispAsn: 'AS37061', country: 'Nigeria', city: 'Lagos' },
      { step: 'Mail Relay', ip: '41.58.12.80', hostname: 'mail.goog1e-accounts.com', ispAsn: 'AS37061', country: 'Nigeria', city: 'Lagos' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '41.58.12.77', hostname: 'globacom.com', ispAsn: 'AS37061 — Globacom', country: 'Nigeria', city: 'Lagos' },
      { step: 'Probable Infrastructure Location', ip: '41.58.12.77', hostname: 'srv77.goog1e-accounts.com', ispAsn: 'AS37061', country: 'Nigeria', city: 'Lagos' },
    ],
    clientExplanation:
      'A fake Google security email was detected claiming someone tried to log into your account. The link goes to a fake Google page that could steal your password.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake Google domain',
      'Email contained a suspicious link to a fake security page',
      'Message created unusual urgency about a login attempt',
      'Domain looked similar to the real Google domain',
    ],
    actionTaken: 'Email blocked',
    recommendedAction: 'Do not click the link. To check your Google account security, go directly to myaccount.google.com.',
  },
  {
    id: 'INC-2024-011',
    senderName: 'Vendor Payments',
    senderEmail: 'payments@vendor-acme.com',
    recipientEmail: 'ap@acmecorp.com',
    cc: 'cfo@acmecorp.com',
    replyTo: 'vendor.pay@ offshore-bank.net',
    subject: 'Updated Banking Details for Vendor Payment',
    dateTime: '2024-08-30 14:10:00 UTC',
    emailId: 'MSG-2a3b4c5d@example.com',
    attachments: ['Updated_Banking_Details.pdf'],
    emailBody:
      'Dear Accounts Team,\n\nPlease note our updated banking details for all future payments. Kindly update your records and route the next payment to the new account as per the attached document.\n\nVendor Payments Team',
    riskScore: 85,
    threatLevel: 'Critical',
    threatType: 'BEC',
    status: 'Escalated',
    clientOrg: 'Acme Corp',
    aiConfidence: 92,
    aiExplanation:
      'This is a vendor impersonation BEC attack attempting to redirect payments to a new bank account. The reply-to address points to an offshore banking domain, and the domain is a lookalike.',
    suspiciousBehavior: [
      'Vendor impersonation BEC',
      'Banking details change request',
      'Reply-to to offshore banking domain',
      'Lookalike domain',
    ],
    urgencyDetected: false,
    financialRequest: true,
    impersonationDetected: true,
    suspiciousLanguage: ['updated banking details', 'update your records', 'route the next payment'],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'FAIL',
    dmarc: 'FAIL',
    senderDomain: 'vendor-acme.com',
    replyToMismatch: true,
    displayNameSpoofing: true,
    domainSimilarityScore: 78,
    urls: [],
    headerInfo: {
      senderIP: '77.81.22.35',
      receivedIPs: ['77.81.22.35', '10.0.1.22'],
      mailRelay: 'mx.vendor-acme.com',
      asnIsp: 'AS9009 — M247 Europe',
      hostname: 'srv35.vendor-acme.com',
      ipReputation: 'Suspicious — Bullet-proof hosting',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 22, description: 'All auth checks failed, reply-to to offshore bank' },
      { category: 'AI/NLP Analysis', score: 22, description: 'Banking details change, financial redirect' },
      { category: 'URL Analysis', score: 5, description: 'No URLs, malicious attachment' },
      { category: 'Domain Reputation', score: 18, description: 'Lookalike domain, suspicious hosting' },
      { category: 'Impersonation Detection', score: 18, description: 'Vendor payment team spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '77.81.22.35', hostname: 'srv35.vendor-acme.com', ispAsn: 'AS9009', country: 'Moldova', city: 'Chisinau' },
      { step: 'Mail Relay', ip: '77.81.22.40', hostname: 'mx.vendor-acme.com', ispAsn: 'AS9009', country: 'Moldova', city: 'Chisinau' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '77.81.22.35', hostname: 'm247.com', ispAsn: 'AS9009 — M247 Europe', country: 'Moldova', city: 'Chisinau' },
      { step: 'Probable Infrastructure Location', ip: '77.81.22.35', hostname: 'srv35.vendor-acme.com', ispAsn: 'AS9009', country: 'Moldova', city: 'Chisinau' },
    ],
    clientExplanation:
      'Someone pretending to be one of your vendors sent an email asking to change their bank account details. This is a scam to redirect your payments to a fraudster account.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake vendor domain',
      'Email requested a change of banking details',
      'Domain looked similar to a trusted vendor domain',
    ],
    actionTaken: 'Email blocked',
    recommendedAction: 'Do not update banking details based on email requests. Always verify banking changes by phone with your known vendor contact.',
  },
  {
    id: 'INC-2024-012',
    senderName: 'DHL Express',
    senderEmail: 'noreply@dhl-tracking.org',
    recipientEmail: 'ops@globex.com',
    cc: '',
    replyTo: '',
    subject: 'Your shipment #DHL44782 is on hold',
    dateTime: '2024-08-29 10:20:00 UTC',
    emailId: 'MSG-7a8b9c0d@example.com',
    attachments: [],
    emailBody:
      'Dear Customer,\n\nYour shipment #DHL44782 is on hold at our facility. A shipping fee of $2.50 is required to release the package. Pay here: https://dhl-tracking.org/pay?id=44782\n\nDHL Express',
    riskScore: 64,
    threatLevel: 'Medium',
    threatType: 'Phishing',
    status: 'Investigating',
    clientOrg: 'Globex Corp',
    aiConfidence: 83,
    aiExplanation:
      'This email impersonates DHL using a lookalike domain. The small fee request is a micro-payment phishing tactic designed to collect payment card details.',
    suspiciousBehavior: [
      'DHL brand impersonation',
      'Lookalike domain (dhl-tracking.org)',
      'Micro-payment phishing',
      'Package on hold lure',
    ],
    urgencyDetected: true,
    financialRequest: true,
    impersonationDetected: true,
    suspiciousLanguage: ['on hold', 'shipping fee', 'required to release'],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'NONE',
    dmarc: 'FAIL',
    senderDomain: 'dhl-tracking.org',
    replyToMismatch: false,
    displayNameSpoofing: true,
    domainSimilarityScore: 66,
    urls: [
      {
        url: 'https://dhl-tracking.org/pay?id=44782',
        destinationDomain: 'dhl-tracking.org',
        classification: 'Suspicious',
        lookalikePercent: 66,
        domainReputation: 'Poor — Phishing domain',
        hostingInfo: 'Shared hosting, Indonesia',
      },
    ],
    headerInfo: {
      senderIP: '103.10.122.44',
      receivedIPs: ['103.10.122.44', '172.16.4.1'],
      mailRelay: 'mail.dhl-tracking.org',
      asnIsp: 'AS45727 — Indonesian ISP',
      hostname: 'srv44.dhl-tracking.org',
      ipReputation: 'Suspicious — Known phishing',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 16, description: 'SPF failed, DMARC failed' },
      { category: 'AI/NLP Analysis', score: 14, description: 'Package hold lure, micro-payment' },
      { category: 'URL Analysis', score: 16, description: 'Lookalike domain, 66% similarity' },
      { category: 'Domain Reputation', score: 12, description: 'Poor reputation shared hosting' },
      { category: 'Impersonation Detection', score: 6, description: 'DHL brand spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '103.10.122.44', hostname: 'srv44.dhl-tracking.org', ispAsn: 'AS45727', country: 'Indonesia', city: 'Jakarta' },
      { step: 'Mail Relay', ip: '103.10.122.50', hostname: 'mail.dhl-tracking.org', ispAsn: 'AS45727', country: 'Indonesia', city: 'Jakarta' },
      { step: 'Mail Server', ip: '172.16.4.1', hostname: 'mail.globex.com', ispAsn: 'Internal', country: 'United States', city: 'San Francisco' },
      { step: 'ISP/ASN', ip: '103.10.122.44', hostname: 'idhosting.net', ispAsn: 'AS45727 — Indonesian ISP', country: 'Indonesia', city: 'Jakarta' },
      { step: 'Probable Infrastructure Location', ip: '103.10.122.44', hostname: 'srv44.dhl-tracking.org', ispAsn: 'AS45727', country: 'Indonesia', city: 'Jakarta' },
    ],
    clientExplanation:
      'A fake DHL email was detected claiming your package is on hold and asking for a small payment fee. The link goes to a fake payment page that could steal your card details.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake DHL domain',
      'Email requested a payment for package release',
      'Email contained a suspicious payment link',
    ],
    actionTaken: 'Email marked suspicious',
    recommendedAction: 'Do not click the link or enter payment information. DHL will not ask for fees via email links.',
  },
  {
    id: 'INC-2024-013',
    senderName: 'Jennifer Lopez',
    senderEmail: 'j.lopez@initech.com',
    recipientEmail: 'manager@initech.com',
    cc: '',
    replyTo: 'j.lopez@initech.com',
    subject: 'Q3 Budget Review Meeting',
    dateTime: '2024-08-29 08:00:00 UTC',
    emailId: 'MSG-5e4d3c2b@example.com',
    attachments: ['Q3_Budget_Review.docx'],
    emailBody:
      'Hi,\n\nJust a reminder about our Q3 budget review meeting scheduled for next Tuesday. I have attached the latest draft for your review.\n\nThanks,\nJennifer',
    riskScore: 12,
    threatLevel: 'Low',
    threatType: 'Legitimate',
    status: 'Resolved',
    clientOrg: 'Initech',
    aiConfidence: 95,
    aiExplanation:
      'This email appears legitimate. The sender domain matches the recipient domain, authentication checks passed, and the content is a standard internal business communication.',
    suspiciousBehavior: [],
    urgencyDetected: false,
    financialRequest: false,
    impersonationDetected: false,
    suspiciousLanguage: [],
    secrecyManipulation: false,
    spf: 'PASS',
    dkim: 'PASS',
    dmarc: 'PASS',
    senderDomain: 'initech.com',
    replyToMismatch: false,
    displayNameSpoofing: false,
    domainSimilarityScore: 0,
    urls: [],
    headerInfo: {
      senderIP: '192.168.1.100',
      receivedIPs: ['192.168.1.100', '10.0.2.15'],
      mailRelay: 'mail.initech.com',
      asnIsp: 'Internal — Initech Corp',
      hostname: 'exchange01.initech.com',
      ipReputation: 'Clean — Internal corporate',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 2, description: 'All authentication checks passed' },
      { category: 'AI/NLP Analysis', score: 2, description: 'Standard business communication' },
      { category: 'URL Analysis', score: 0, description: 'No URLs present' },
      { category: 'Domain Reputation', score: 2, description: 'Legitimate internal domain' },
      { category: 'Impersonation Detection', score: 6, description: 'No impersonation indicators' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '192.168.1.100', hostname: 'exchange01.initech.com', ispAsn: 'Internal', country: 'United States', city: 'Austin' },
      { step: 'Mail Relay', ip: '192.168.1.105', hostname: 'mail.initech.com', ispAsn: 'Internal', country: 'United States', city: 'Austin' },
      { step: 'Mail Server', ip: '10.0.2.15', hostname: 'mail.initech.com', ispAsn: 'Internal', country: 'United States', city: 'Austin' },
      { step: 'ISP/ASN', ip: '192.168.1.100', hostname: 'initech.com', ispAsn: 'Internal — Initech Corp', country: 'United States', city: 'Austin' },
      { step: 'Probable Infrastructure Location', ip: '192.168.1.100', hostname: 'exchange01.initech.com', ispAsn: 'Internal', country: 'United States', city: 'Austin' },
    ],
    clientExplanation:
      'This email was checked and appears to be a normal internal business email about a budget meeting. No threats were detected.',
    clientWhyFlagged: [],
    actionTaken: 'No action needed',
    recommendedAction: 'This email is safe. No action is required.',
  },
  {
    id: 'INC-2024-014',
    senderName: 'Support Team',
    senderEmail: 'support@cloudflare-verify.com',
    recipientEmail: 'ops@globex.com',
    cc: '',
    replyTo: 'admin@cloudflare-verify.com',
    subject: 'Your SSL certificate expires in 24 hours',
    dateTime: '2024-08-28 16:45:00 UTC',
    emailId: 'MSG-3d4e5f6a@example.com',
    attachments: [],
    emailBody:
      'Dear Administrator,\n\nYour SSL certificate for globex.com will expire in 24 hours. To prevent service interruption, please renew immediately: https://cloudflare-verify.com/renew?domain=globex.com\n\nSupport Team',
    riskScore: 53,
    threatLevel: 'Medium',
    threatType: 'Suspicious',
    status: 'New',
    clientOrg: 'Globex Corp',
    aiConfidence: 76,
    aiExplanation:
      'This email uses a lookalike Cloudflare domain to create urgency about SSL certificate expiration. The renewal link likely leads to a credential harvesting or payment page.',
    suspiciousBehavior: [
      'Cloudflare brand impersonation',
      'Lookalike domain (cloudflare-verify.com)',
      'SSL expiry urgency tactic',
      'Reply-to mismatch',
    ],
    urgencyDetected: true,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: ['expires in 24 hours', 'prevent service interruption', 'renew immediately'],
    secrecyManipulation: false,
    spf: 'NONE',
    dkim: 'FAIL',
    dmarc: 'FAIL',
    senderDomain: 'cloudflare-verify.com',
    replyToMismatch: false,
    displayNameSpoofing: true,
    domainSimilarityScore: 58,
    urls: [
      {
        url: 'https://cloudflare-verify.com/renew?domain=globex.com',
        destinationDomain: 'cloudflare-verify.com',
        classification: 'Suspicious',
        lookalikePercent: 58,
        domainReputation: 'Suspicious — Lookalike domain',
        hostingInfo: 'VPS, Germany',
      },
    ],
    headerInfo: {
      senderIP: '116.203.88.12',
      receivedIPs: ['116.203.88.12', '172.16.4.1'],
      mailRelay: 'mail.cloudflare-verify.com',
      asnIsp: 'AS24940 — Hetzner Online',
      hostname: 'vps12.cloudflare-verify.com',
      ipReputation: 'Suspicious — Lookalike hosting',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 14, description: 'DKIM failed, DMARC failed' },
      { category: 'AI/NLP Analysis', score: 14, description: 'SSL expiry urgency, renewal lure' },
      { category: 'URL Analysis', score: 12, description: 'Lookalike domain, 58% similarity' },
      { category: 'Domain Reputation', score: 9, description: 'Suspicious VPS hosting' },
      { category: 'Impersonation Detection', score: 4, description: 'Cloudflare brand spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '116.203.88.12', hostname: 'vps12.cloudflare-verify.com', ispAsn: 'AS24940', country: 'Germany', city: 'Falkenstein' },
      { step: 'Mail Relay', ip: '116.203.88.18', hostname: 'mail.cloudflare-verify.com', ispAsn: 'AS24940', country: 'Germany', city: 'Falkenstein' },
      { step: 'Mail Server', ip: '172.16.4.1', hostname: 'mail.globex.com', ispAsn: 'Internal', country: 'United States', city: 'San Francisco' },
      { step: 'ISP/ASN', ip: '116.203.88.12', hostname: 'hetzner.com', ispAsn: 'AS24940 — Hetzner', country: 'Germany', city: 'Falkenstein' },
      { step: 'Probable Infrastructure Location', ip: '116.203.88.12', hostname: 'vps12.cloudflare-verify.com', ispAsn: 'AS24940', country: 'Germany', city: 'Falkenstein' },
    ],
    clientExplanation:
      'A suspicious email pretending to be from Cloudflare was detected, claiming your website SSL certificate was about to expire. The link goes to a fake renewal page.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake Cloudflare domain',
      'Email contained a suspicious renewal link',
      'Message created unusual urgency about certificate expiry',
    ],
    actionTaken: 'Email marked suspicious',
    recommendedAction: 'Do not click the link. Check your SSL certificate status directly in your Cloudflare dashboard.',
  },
  {
    id: 'INC-2024-015',
    senderName: 'Bank of America',
    senderEmail: 'security@bankofarnetica.com',
    recipientEmail: 'finance@acmecorp.com',
    cc: '',
    replyTo: 'verify@bankofarnetica-secure.com',
    subject: 'Unusual Activity Detected on Your Business Account',
    dateTime: '2024-08-28 13:15:00 UTC',
    emailId: 'MSG-1b2c3d4e5f@example.com',
    attachments: [],
    emailBody:
      'Dear Customer,\n\nWe have detected unusual activity on your Business account ending in 4471. A transfer of $15,200 was initiated from an unknown device. If you did not authorize this, please verify your identity: https://bankofarnetica.com/verify?acct=4471\n\nBank of America Security',
    riskScore: 82,
    threatLevel: 'High',
    threatType: 'Phishing',
    status: 'Investigating',
    clientOrg: 'Acme Corp',
    aiConfidence: 90,
    aiExplanation:
      'This email impersonates Bank of America using a lookalike domain (bankofarnetica.com). The unauthorized transfer alert creates urgency to harvest banking credentials.',
    suspiciousBehavior: [
      'Bank of America brand impersonation',
      'Lookalike domain (bankofarnetica.com)',
      'Unauthorized transfer urgency',
      'Reply-to mismatch to secondary lookalike',
      'Credential harvesting link',
    ],
    urgencyDetected: true,
    financialRequest: false,
    impersonationDetected: true,
    suspiciousLanguage: ['unusual activity', 'unknown device', 'if you did not authorize'],
    secrecyManipulation: false,
    spf: 'FAIL',
    dkim: 'FAIL',
    dmarc: 'FAIL',
    senderDomain: 'bankofarnetica.com',
    replyToMismatch: true,
    displayNameSpoofing: true,
    domainSimilarityScore: 81,
    urls: [
      {
        url: 'https://bankofarnetica.com/verify?acct=4471',
        destinationDomain: 'bankofarnetica.com',
        classification: 'Malicious',
        lookalikePercent: 81,
        domainReputation: 'Poor — Phishing domain',
        hostingInfo: 'Shared hosting, Panama',
      },
    ],
    headerInfo: {
      senderIP: '190.120.20.88',
      receivedIPs: ['190.120.20.88', '10.0.1.22'],
      mailRelay: 'mail.bankofarnetica.com',
      asnIsp: 'AS262287 — Panama Hosting',
      hostname: 'srv88.bankofarnetica.com',
      ipReputation: 'Malicious — Known phishing source',
    },
    riskBreakdown: [
      { category: 'Header Analysis', score: 22, description: 'All auth checks failed, reply-to mismatch' },
      { category: 'AI/NLP Analysis', score: 20, description: 'Unauthorized transfer urgency, credential harvesting' },
      { category: 'URL Analysis', score: 18, description: 'Lookalike domain, 81% similarity' },
      { category: 'Domain Reputation', score: 14, description: 'Poor reputation, Panamanian hosting' },
      { category: 'Impersonation Detection', score: 8, description: 'Bank of America brand spoofing' },
    ],
    traceNodes: [
      { step: 'Sender', ip: '190.120.20.88', hostname: 'srv88.bankofarnetica.com', ispAsn: 'AS262287', country: 'Panama', city: 'Panama City' },
      { step: 'Mail Relay', ip: '190.120.20.95', hostname: 'mail.bankofarnetica.com', ispAsn: 'AS262287', country: 'Panama', city: 'Panama City' },
      { step: 'Mail Server', ip: '10.0.1.22', hostname: 'mail.acmecorp.com', ispAsn: 'Internal', country: 'United States', city: 'New York' },
      { step: 'ISP/ASN', ip: '190.120.20.88', hostname: 'panamahost.com', ispAsn: 'AS262287 — Panama Hosting', country: 'Panama', city: 'Panama City' },
      { step: 'Probable Infrastructure Location', ip: '190.120.20.88', hostname: 'srv88.bankofarnetica.com', ispAsn: 'AS262287', country: 'Panama', city: 'Panama City' },
    ],
    clientExplanation:
      'A fake Bank of America email was detected claiming unusual activity on your account. The link goes to a fake bank page that could steal your banking login details.',
    clientWhyFlagged: [
      'Sender identity appeared suspicious — fake Bank of America domain',
      'Email contained a suspicious link to a fake verification page',
      'Message created unusual urgency about an unauthorized transfer',
      'Domain looked similar to the real Bank of America domain',
    ],
    actionTaken: 'Email blocked',
    recommendedAction: 'Do not click the link or enter any banking credentials. Log in to your bank directly through the official website or app.',
  },
];

export const campaigns: Campaign[] = [
  {
    id: 'CAMPAIGN-017',
    name: 'Lookalike Domain Attack — Microsoft/Google Impersonation',
    incidentIds: ['INC-2024-002', 'INC-2024-010'],
    commonSenderDomain: 'Various typosquatting domains',
    commonUrl: 'Credential harvesting verification pages',
    firstDetected: '2024-08-28',
    lastDetected: '2024-09-03',
    severity: 'Critical',
  },
  {
    id: 'CAMPAIGN-018',
    name: 'BEC Wire Transfer Campaign — Executive Impersonation',
    incidentIds: ['INC-2024-001', 'INC-2024-004', 'INC-2024-011'],
    commonSenderDomain: 'Lookalike executive/vendor domains',
    commonUrl: 'N/A — Attachment-based',
    firstDetected: '2024-08-28',
    lastDetected: '2024-09-03',
    severity: 'Critical',
  },
  {
    id: 'CAMPAIGN-019',
    name: 'Shipping Phishing Wave — FedEx/DHL Impersonation',
    incidentIds: ['INC-2024-009', 'INC-2024-012'],
    commonSenderDomain: 'fedex-ship.net, dhl-tracking.org',
    commonUrl: 'Package tracking/payment links',
    firstDetected: '2024-08-29',
    lastDetected: '2024-08-31',
    severity: 'High',
  },
  {
    id: 'CAMPAIGN-020',
    name: 'IT Helpdesk Credential Harvesting',
    incidentIds: ['INC-2024-005', 'INC-2024-014'],
    commonSenderDomain: 'Lookalike internal/infrastructure domains',
    commonUrl: 'Password reset / SSL renewal pages',
    firstDetected: '2024-08-28',
    lastDetected: '2024-09-02',
    severity: 'High',
  },
];

export const cases: Case[] = [
  {
    id: 'CASE-001',
    incidentId: 'INC-2024-001',
    priority: 'Critical',
    assignedInvestigator: 'Sarah Mitchell',
    status: 'Investigating',
    createdDate: '2024-09-03',
    lastUpdated: '2024-09-04',
  },
  {
    id: 'CASE-002',
    incidentId: 'INC-2024-002',
    priority: 'Critical',
    assignedInvestigator: 'James Park',
    status: 'Investigating',
    createdDate: '2024-09-03',
    lastUpdated: '2024-09-04',
  },
  {
    id: 'CASE-003',
    incidentId: 'INC-2024-004',
    priority: 'Critical',
    assignedInvestigator: 'Sarah Mitchell',
    status: 'Escalated',
    createdDate: '2024-09-02',
    lastUpdated: '2024-09-04',
  },
  {
    id: 'CASE-004',
    incidentId: 'INC-2024-011',
    priority: 'Critical',
    assignedInvestigator: 'Emily Chen',
    status: 'Escalated',
    createdDate: '2024-08-30',
    lastUpdated: '2024-09-03',
  },
  {
    id: 'CASE-005',
    incidentId: 'INC-2024-003',
    priority: 'High',
    assignedInvestigator: 'James Park',
    status: 'Investigating',
    createdDate: '2024-09-02',
    lastUpdated: '2024-09-03',
  },
  {
    id: 'CASE-006',
    incidentId: 'INC-2024-005',
    priority: 'High',
    assignedInvestigator: 'Emily Chen',
    status: 'Investigating',
    createdDate: '2024-09-02',
    lastUpdated: '2024-09-03',
  },
  {
    id: 'CASE-007',
    incidentId: 'INC-2024-009',
    priority: 'High',
    assignedInvestigator: 'James Park',
    status: 'Investigating',
    createdDate: '2024-08-31',
    lastUpdated: '2024-09-02',
  },
  {
    id: 'CASE-008',
    incidentId: 'INC-2024-015',
    priority: 'High',
    assignedInvestigator: 'Sarah Mitchell',
    status: 'Investigating',
    createdDate: '2024-08-28',
    lastUpdated: '2024-09-03',
  },
  {
    id: 'CASE-009',
    incidentId: 'INC-2024-008',
    priority: 'Medium',
    assignedInvestigator: 'Emily Chen',
    status: 'Resolved',
    createdDate: '2024-08-31',
    lastUpdated: '2024-09-01',
  },
  {
    id: 'CASE-010',
    incidentId: 'INC-2024-010',
    priority: 'High',
    assignedInvestigator: 'James Park',
    status: 'Resolved',
    createdDate: '2024-08-30',
    lastUpdated: '2024-09-01',
  },
  {
    id: 'CASE-011',
    incidentId: 'INC-2024-013',
    priority: 'Low',
    assignedInvestigator: 'Emily Chen',
    status: 'Resolved',
    createdDate: '2024-08-29',
    lastUpdated: '2024-08-29',
  },
  {
    id: 'CASE-012',
    incidentId: 'INC-2024-006',
    priority: 'Medium',
    assignedInvestigator: 'Sarah Mitchell',
    status: 'New',
    createdDate: '2024-09-01',
    lastUpdated: '2024-09-01',
  },
];

export const reports: Report[] = [
  {
    id: 'RPT-001',
    caseId: 'CASE-001',
    incidentId: 'INC-2024-001',
    title: 'Forensic Report — BEC Wire Transfer Attempt',
    generatedDate: '2024-09-04',
    attributionConfidence: 94,
  },
  {
    id: 'RPT-002',
    caseId: 'CASE-002',
    incidentId: 'INC-2024-002',
    title: 'Forensic Report — Microsoft Credential Phishing',
    generatedDate: '2024-09-04',
    attributionConfidence: 92,
  },
  {
    id: 'RPT-003',
    caseId: 'CASE-003',
    incidentId: 'INC-2024-004',
    title: 'Forensic Report — CEO Gift Card Scam',
    generatedDate: '2024-09-03',
    attributionConfidence: 95,
  },
  {
    id: 'RPT-004',
    caseId: 'CASE-004',
    incidentId: 'INC-2024-011',
    title: 'Forensic Report — Vendor Banking Redirect BEC',
    generatedDate: '2024-09-03',
    attributionConfidence: 90,
  },
  {
    id: 'RPT-005',
    caseId: 'CASE-010',
    incidentId: 'INC-2024-010',
    title: 'Forensic Report — Google Typosquatting Phishing',
    generatedDate: '2024-09-01',
    attributionConfidence: 88,
  },
  {
    id: 'RPT-006',
    caseId: 'CASE-009',
    incidentId: 'INC-2024-008',
    title: 'Forensic Report — HR Portal Lookalike',
    generatedDate: '2024-09-01',
    attributionConfidence: 72,
  },
];

export function getIncidentById(id: string): Incident | undefined {
  return incidents.find((i) => i.id === id);
}

export function getIncidentsByOrg(org: string): Incident[] {
  return incidents.filter((i) => i.clientOrg === org);
}

export function getCampaignById(id: string): Campaign | undefined {
  return campaigns.find((c) => c.id === id);
}

export function getCaseById(id: string): Case | undefined {
  return cases.find((c) => c.id === id);
}

export function getReportById(id: string): Report | undefined {
  return reports.find((r) => r.id === id);
}

export const dashboardStats = {
  totalEmails: 158234,
  totalThreats: incidents.length,
  criticalThreats: incidents.filter((i) => i.threatLevel === 'Critical').length,
  highThreats: incidents.filter((i) => i.threatLevel === 'High').length,
  mediumThreats: incidents.filter((i) => i.threatLevel === 'Medium').length,
  lowThreats: incidents.filter((i) => i.threatLevel === 'Low').length,
  avgRiskScore: Math.round(incidents.reduce((sum, i) => sum + i.riskScore, 0) / incidents.length),
};

export const clientDashboardStats = {
  emailsProtected: 42837,
  threatsDetected: incidents.filter((i) => i.clientOrg === 'Acme Corp').length,
  threatsBlocked: incidents.filter((i) => i.clientOrg === 'Acme Corp' && i.actionTaken === 'Email blocked').length,
  openIncidents: incidents.filter((i) => i.clientOrg === 'Acme Corp' && i.status !== 'Resolved').length,
};
