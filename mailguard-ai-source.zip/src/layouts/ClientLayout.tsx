import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { ShieldCheck, LayoutDashboard, Inbox, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { to: '/client', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/client/incidents', label: 'My Incidents', icon: Inbox },
];

export default function ClientLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-cyber-bg flex flex-col">
      {/* Top nav */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-cyber-border h-16 flex items-center px-4 lg:px-6">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-accent-600 rounded-xl flex items-center justify-center shadow-sm">
            <ShieldCheck className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-cyber-text text-sm">MailGuard AI</h1>
            <p className="text-cyber-muted text-[11px]">{user?.org} — Client Portal</p>
          </div>
        </div>

        <div className="flex-1" />

        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  isActive ? 'bg-accent-600 text-white' : 'text-cyber-muted hover:bg-accent-50 hover:text-accent-700'
                }`
              }
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-3 ml-3">
          <div className="hidden lg:flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-accent-100 border border-accent-200 flex items-center justify-center">
              <span className="text-sm font-semibold text-accent-700">
                {user?.name?.charAt(0) || 'C'}
              </span>
            </div>
            <span className="text-sm font-medium text-cyber-text hidden xl:block">{user?.name}</span>
          </div>
          <button
            onClick={handleLogout}
            className="btn-ghost text-sm"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>

        <button
          onClick={() => setSidebarOpen(true)}
          className="md:hidden p-2 -mr-2 text-cyber-muted hover:text-accent-600 ml-2"
        >
          <Menu className="w-5 h-5" />
        </button>
      </header>

      {/* Mobile nav */}
      {sidebarOpen && (
        <>
          <div className="fixed inset-0 bg-black/30 z-40 md:hidden" onClick={() => setSidebarOpen(false)} />
          <div className="fixed top-0 right-0 h-full w-64 bg-white z-50 shadow-xl md:hidden p-4 animate-slide-in">
            <div className="flex justify-between items-center mb-6">
              <span className="font-bold text-cyber-text">Menu</span>
              <button onClick={() => setSidebarOpen(false)} className="text-cyber-muted">
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="space-y-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.end}
                  onClick={() => setSidebarOpen(false)}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                      isActive ? 'bg-accent-600 text-white' : 'text-cyber-muted hover:bg-accent-50'
                    }`
                  }
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </NavLink>
              ))}
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50"
              >
                <LogOut className="w-5 h-5" />
                Sign Out
              </button>
            </nav>
          </div>
        </>
      )}

      {/* Page content */}
      <main className="flex-1 p-4 lg:p-8 max-w-6xl mx-auto w-full animate-fade-in">
        <Outlet />
      </main>
    </div>
  );
}
