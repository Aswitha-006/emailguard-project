import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import Login from '@/pages/Login';
import ClientRegistration from '@/pages/ClientRegistration';
import InvestigatorLayout from '@/layouts/InvestigatorLayout';
import ClientLayout from '@/layouts/ClientLayout';
import InvestigatorDashboard from '@/pages/investigator/Dashboard';
import Alerts from '@/pages/investigator/Alerts';
import IncidentDetail from '@/pages/investigator/IncidentDetail';
import Trace from '@/pages/investigator/Trace';
import Campaigns from '@/pages/investigator/Campaigns';
import Cases from '@/pages/investigator/Cases';
import Reports from '@/pages/investigator/Reports';
import ClientDashboard from '@/pages/client/Dashboard';
import ClientIncidents from '@/pages/client/Incidents';
import ClientIncidentDetail from '@/pages/client/IncidentDetail';

function RootRedirect() {
  const { user } = useAuth();
  if (user?.role === 'investigator') return <Navigate to="/investigator" replace />;
  if (user?.role === 'client') return <Navigate to="/client" replace />;
  return <Login />;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<RootRedirect />} />
          <Route path="/register" element={<ClientRegistration />} />

          {/* Investigator routes */}
          <Route path="/investigator" element={<InvestigatorLayout />}>
            <Route index element={<InvestigatorDashboard />} />
            <Route path="alerts" element={<Alerts />} />
            <Route path="incidents/:id" element={<IncidentDetail />} />
            <Route path="trace/:id" element={<Trace />} />
            <Route path="campaigns" element={<Campaigns />} />
            <Route path="cases" element={<Cases />} />
            <Route path="reports" element={<Reports />} />
          </Route>

          {/* Client routes */}
          <Route path="/client" element={<ClientLayout />}>
            <Route index element={<ClientDashboard />} />
            <Route path="incidents" element={<ClientIncidents />} />
            <Route path="incidents/:id" element={<ClientIncidentDetail />} />
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
