import { Link } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { getIncidentsByOrg, clientDashboardStats } from '@/data/mockData';
import { getThreatLevelColor, getStatusColor } from '@/utils/helpers';
import { SimpleThreatChart } from '@/components/ui/Charts';
import { ShieldCheck, Mail, AlertTriangle, Ban, Inbox, ArrowRight, Shield } from 'lucide-react';

export default function ClientDashboard() {
  const { user } = useAuth();
  const orgIncidents = getIncidentsByOrg(user?.org || 'Acme Corp');
  const stats = {
    ...clientDashboardStats,
    threatsDetected: orgIncidents.length,
    threatsBlocked: orgIncidents.filter((i) => i.actionTaken === 'Email blocked').length,
    openIncidents: orgIncidents.filter((i) => i.status !== 'Resolved').length,
  };

  const recentIncidents = orgIncidents.slice(0, 5);

  const cards = [
    { label: 'Emails Protected', value: stats.emailsProtected.toLocaleString(), icon: Mail, color: 'text-accent-600', bg: 'bg-accent-50' },
    { label: 'Threats Detected', value: stats.threatsDetected, icon: AlertTriangle, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Threats Blocked', value: stats.threatsBlocked, icon: Ban, color: 'text-red-600', bg: 'bg-red-50' },
    { label: 'Open Incidents', value: stats.openIncidents, icon: Inbox, color: 'text-amber-600', bg: 'bg-amber-50' },
  ];

  return (
    <div className="space-y-6">
      {/* Hero banner */}
      <div className="bg-gradient-to-r from-accent-600 to-accent-700 rounded-2xl p-6 lg:p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/4 blur-2xl" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck className="w-5 h-5" />
            <span className="text-sm font-medium text-white/80">Your organization is protected</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-bold">{user?.org} — Security Dashboard</h1>
          <p className="text-white/80 mt-2 max-w-lg">
            Your organization's email security is being actively monitored. We detect and block threats before they reach your inbox.
          </p>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => (
          <div key={card.label} className="card p-5 animate-slide-up">
            <div className={`w-10 h-10 rounded-xl ${card.bg} flex items-center justify-center mb-3`}>
              <card.icon className={`w-5 h-5 ${card.color}`} />
            </div>
            <p className="text-2xl font-bold text-cyber-text">{card.value}</p>
            <p className="text-xs text-cyber-muted mt-1">{card.label}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent incidents */}
        <div className="lg:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-cyber-text">Recent Security Incidents</h2>
            <Link to="/client/incidents" className="text-sm text-accent-600 hover:text-accent-700 font-medium flex items-center gap-1">
              View all <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="space-y-2">
            {recentIncidents.map((inc) => (
              <Link
                key={inc.id}
                to={`/client/incidents/${inc.id}`}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-accent-50 transition-all group border border-transparent hover:border-accent-200"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  inc.threatLevel === 'Critical' ? 'bg-red-50' : inc.threatLevel === 'High' ? 'bg-orange-50' : 'bg-amber-50'
                }`}>
                  <Shield className={`w-5 h-5 ${
                    inc.threatLevel === 'Critical' ? 'text-red-600' : inc.threatLevel === 'High' ? 'text-orange-600' : 'text-amber-600'
                  }`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-cyber-text truncate">{inc.clientExplanation.split('.')[0]}</p>
                  <p className="text-xs text-cyber-muted truncate">{inc.subject}</p>
                </div>
                <span className={`badge ${getThreatLevelColor(inc.threatLevel)} shrink-0`}>{inc.threatLevel}</span>
              </Link>
            ))}
            {recentIncidents.length === 0 && (
              <div className="text-center py-8 text-cyber-muted text-sm">
                <ShieldCheck className="w-8 h-8 mx-auto mb-2 text-green-500" />
                No incidents detected. Your inbox is safe.
              </div>
            )}
          </div>
        </div>

        {/* Simple threat chart */}
        <div className="card p-5">
          <h2 className="font-semibold text-cyber-text mb-4">Threat Types Detected</h2>
          <SimpleThreatChart />
          <div className="mt-6 pt-4 border-t border-cyber-border">
            <div className="flex items-center gap-2 text-sm text-cyber-muted mb-1">
              <ShieldCheck className="w-4 h-4 text-green-600" />
              Protection Status
            </div>
            <p className="text-sm font-medium text-green-600">Active & Monitoring</p>
          </div>
        </div>
      </div>
    </div>
  );
}
