import { useParams, Link } from 'react-router-dom';
import { getIncidentById } from '@/data/mockData';
import { getThreatLevelColor, getStatusColor } from '@/utils/helpers';
import { RiskGauge, Toast } from '@/components/ui/Primitives';
import {
  ArrowLeft,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  Download,
  HelpCircle,
} from 'lucide-react';
import { useState } from 'react';

export default function ClientIncidentDetail() {
  const { id } = useParams();
  const incident = id ? getIncidentById(id) : undefined;
  const [showToast, setShowToast] = useState(false);

  if (!incident) {
    return (
      <div className="text-center py-20">
        <p className="text-cyber-muted">Incident not found.</p>
        <Link to="/client/incidents" className="text-accent-600 hover:underline mt-2 inline-block">Back to My Incidents</Link>
      </div>
    );
  }

  const fireToast = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2500);
  };

  const actionColor = incident.actionTaken === 'Email blocked'
    ? 'text-red-700 bg-red-50 border-red-200'
    : incident.actionTaken === 'Email quarantined'
    ? 'text-orange-700 bg-orange-50 border-orange-200'
    : incident.actionTaken === 'Email marked suspicious'
    ? 'text-amber-700 bg-amber-50 border-amber-200'
    : 'text-accent-700 bg-accent-50 border-accent-200';

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div>
        <Link to="/client/incidents" className="text-sm text-cyber-muted hover:text-accent-600 mb-3 inline-flex items-center gap-1 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to My Incidents
        </Link>
        <div className="flex items-center gap-2 flex-wrap mb-2">
          <span className="text-xs font-mono text-cyber-muted">{incident.id}</span>
          <span className={`badge ${getThreatLevelColor(incident.threatLevel)}`}>{incident.threatLevel}</span>
          <span className={`badge ${getStatusColor(incident.status)}`}>{incident.status}</span>
        </div>
        <h1 className="text-xl font-bold text-cyber-text">Incident Details</h1>
      </div>

      {/* What happened */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-accent-100 flex items-center justify-center">
            <HelpCircle className="w-4 h-4 text-accent-600" />
          </div>
          <h2 className="font-semibold text-cyber-text">What happened?</h2>
        </div>
        <p className="text-sm text-cyber-text leading-relaxed">{incident.clientExplanation}</p>
        <div className="mt-4 grid sm:grid-cols-2 gap-3 text-sm">
          <div className="bg-gray-50 rounded-xl p-3 border border-cyber-border">
            <p className="text-xs text-cyber-muted">Sender</p>
            <p className="font-mono text-cyber-text text-xs break-all">{incident.senderEmail}</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-3 border border-cyber-border">
            <p className="text-xs text-cyber-muted">Subject</p>
            <p className="text-cyber-text text-xs">{incident.subject}</p>
          </div>
        </div>
      </div>

      {/* Why was it flagged */}
      {incident.clientWhyFlagged.length > 0 && (
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-orange-600" />
            </div>
            <h2 className="font-semibold text-cyber-text">Why was it flagged?</h2>
          </div>
          <ul className="space-y-2">
            {incident.clientWhyFlagged.map((reason, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-cyber-text">
                <div className="w-5 h-5 rounded-full bg-orange-100 flex items-center justify-center shrink-0 mt-0.5">
                  <span className="text-[10px] font-bold text-orange-600">{i + 1}</span>
                </div>
                {reason}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Risk */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center">
            <Shield className="w-4 h-4 text-red-600" />
          </div>
          <h2 className="font-semibold text-cyber-text">Risk</h2>
        </div>
        <div className="flex items-center gap-6 flex-wrap">
          <RiskGauge score={incident.riskScore} size="md" />
          <div className="space-y-2 flex-1 min-w-[180px]">
            <div>
              <p className="text-xs text-cyber-muted">Risk Score</p>
              <p className="text-lg font-bold text-cyber-text">{incident.riskScore}/100</p>
            </div>
            <div>
              <p className="text-xs text-cyber-muted">Risk Level</p>
              <span className={`badge ${getThreatLevelColor(incident.threatLevel)}`}>{incident.threatLevel}</span>
            </div>
            <div>
              <p className="text-xs text-cyber-muted">Threat Type</p>
              <p className="text-sm font-medium text-cyber-text">{incident.threatType}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Action Taken */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
          </div>
          <h2 className="font-semibold text-cyber-text">Action Taken</h2>
        </div>
        <div className={`rounded-xl p-4 border ${actionColor}`}>
          <p className="text-sm font-medium">{incident.actionTaken}</p>
        </div>
      </div>

      {/* Recommended Action */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-accent-100 flex items-center justify-center">
            <Lightbulb className="w-4 h-4 text-accent-600" />
          </div>
          <h2 className="font-semibold text-cyber-text">Recommended Action</h2>
        </div>
        <p className="text-sm text-cyber-text leading-relaxed bg-accent-50 rounded-xl p-4 border border-accent-100">
          {incident.recommendedAction}
        </p>
      </div>

      {/* Download Summary */}
      <div className="flex justify-center">
        <button onClick={fireToast} className="btn-primary">
          <Download className="w-4 h-4" /> Download Summary Report
        </button>
      </div>

      <Toast message="Summary report downloaded (demo)" visible={showToast} />
    </div>
  );
}
