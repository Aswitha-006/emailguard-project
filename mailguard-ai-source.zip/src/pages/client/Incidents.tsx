import { Link } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { getIncidentsByOrg } from '@/data/mockData';
import { getThreatLevelColor, getStatusColor } from '@/utils/helpers';
import { Shield, ArrowRight, Inbox } from 'lucide-react';

export default function ClientIncidents() {
  const { user } = useAuth();
  const orgIncidents = getIncidentsByOrg(user?.org || 'Acme Corp');

  const getSimpleName = (incident: { threatType: string; clientExplanation: string }) => {
    const text = incident.clientExplanation;
    if (text.includes('phishing')) return 'Possible phishing email';
    if (text.includes('gift card') || text.includes('CEO') || text.includes('executive')) return 'Executive impersonation attempt';
    if (text.includes('wire transfer') || text.includes('banking')) return 'Suspicious payment request';
    if (text.includes('login') || text.includes('password')) return 'Suspicious login email';
    if (text.includes('link')) return 'Malicious link detected';
    return 'Suspicious email detected';
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-cyber-text">My Incidents</h1>
        <p className="text-cyber-muted mt-1">Security incidents detected for {user?.org}</p>
      </div>

      {orgIncidents.length === 0 ? (
        <div className="card p-12 text-center">
          <Inbox className="w-12 h-12 mx-auto text-cyber-muted mb-3" />
          <p className="text-cyber-muted">No incidents detected for your organization.</p>
        </div>
      ) : (
        <div className="grid gap-3">
          {orgIncidents.map((inc) => (
            <Link
              key={inc.id}
              to={`/client/incidents/${inc.id}`}
              className="card p-4 hover:border-accent-300 transition-all group block"
            >
              <div className="flex items-start gap-4">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                  inc.threatLevel === 'Critical' ? 'bg-red-50' :
                  inc.threatLevel === 'High' ? 'bg-orange-50' :
                  inc.threatLevel === 'Medium' ? 'bg-amber-50' : 'bg-green-50'
                }`}>
                  <Shield className={`w-5 h-5 ${
                    inc.threatLevel === 'Critical' ? 'text-red-600' :
                    inc.threatLevel === 'High' ? 'text-orange-600' :
                    inc.threatLevel === 'Medium' ? 'text-amber-600' : 'text-green-600'
                  }`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-xs font-mono text-cyber-muted">{inc.id}</span>
                    <span className={`badge ${getThreatLevelColor(inc.threatLevel)}`}>{inc.threatLevel}</span>
                    <span className={`badge ${getStatusColor(inc.status)}`}>{inc.status}</span>
                  </div>
                  <p className="text-sm font-medium text-cyber-text">{getSimpleName(inc)}</p>
                  <p className="text-xs text-cyber-muted mt-0.5 truncate">From: {inc.senderEmail}</p>
                  <p className="text-xs text-cyber-muted truncate">Subject: {inc.subject}</p>
                  <p className="text-[11px] text-cyber-muted mt-1">{inc.dateTime}</p>
                </div>
                <ArrowRight className="w-5 h-5 text-cyber-muted group-hover:text-accent-600 transition-colors shrink-0 mt-2" />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
