import { Link } from 'react-router-dom';
import { incidents, dashboardStats } from '@/data/mockData';
import { getThreatLevelColor, getStatusColor } from '@/utils/helpers';
import { SeverityChart } from '@/components/ui/Charts';
import {
  Mail,
  AlertTriangle,
  ShieldAlert,
  TrendingUp,
  Activity,
  ArrowRight,
  Clock,
} from 'lucide-react';

export default function InvestigatorDashboard() {
  const stats = dashboardStats;
  const recentIncidents = [...incidents].sort((a, b) => b.riskScore - a.riskScore).slice(0, 6);

  const statCards = [
    { label: 'Emails Analyzed', value: stats.totalEmails.toLocaleString(), icon: Mail, color: 'text-accent-600', bg: 'bg-accent-50' },
    { label: 'Threats Detected', value: stats.totalThreats, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
    { label: 'Critical Threats', value: stats.criticalThreats, icon: ShieldAlert, color: 'text-red-600', bg: 'bg-red-50' },
    { label: 'High-Risk Threats', value: stats.highThreats, icon: AlertTriangle, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Medium-Risk Threats', value: stats.mediumThreats, icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Avg Risk Score', value: stats.avgRiskScore, icon: TrendingUp, color: 'text-accent-600', bg: 'bg-accent-50' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-cyber-text">Investigator Dashboard</h1>
        <p className="text-cyber-muted mt-1">Overview of email threats, detections, and active incidents</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {statCards.map((card) => (
          <div key={card.label} className="card p-4 animate-slide-up">
            <div className={`w-10 h-10 rounded-xl ${card.bg} flex items-center justify-center mb-3`}>
              <card.icon className={`w-5 h-5 ${card.color}`} />
            </div>
            <p className="text-2xl font-bold text-cyber-text">{card.value}</p>
            <p className="text-xs text-cyber-muted mt-1">{card.label}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent suspicious emails */}
        <div className="lg:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-cyber-text">Recent Suspicious Emails</h2>
            <Link to="/investigator/alerts" className="text-sm text-accent-600 hover:text-accent-700 font-medium flex items-center gap-1">
              View all <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="space-y-2">
            {recentIncidents.map((inc) => (
              <Link
                key={inc.id}
                to={`/investigator/incidents/${inc.id}`}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-accent-50 transition-all group border border-transparent hover:border-accent-200"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono text-cyber-muted">{inc.id}</span>
                    <span className={`badge ${getThreatLevelColor(inc.threatLevel)}`}>{inc.threatLevel}</span>
                  </div>
                  <p className="text-sm font-medium text-cyber-text truncate">{inc.subject}</p>
                  <p className="text-xs text-cyber-muted truncate">{inc.senderEmail} → {inc.recipientEmail}</p>
                </div>
                <div className="text-right shrink-0">
                  <div className={`text-lg font-bold ${inc.riskScore >= 80 ? 'text-red-600' : inc.riskScore >= 60 ? 'text-orange-600' : 'text-amber-600'}`}>
                    {inc.riskScore}
                  </div>
                  <div className="text-[10px] text-cyber-muted">risk</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Threat severity chart */}
        <div className="card p-5">
          <h2 className="font-semibold text-cyber-text mb-4">Threat Severity Distribution</h2>
          <SeverityChart />
          <div className="mt-6 pt-4 border-t border-cyber-border">
            <div className="flex items-center gap-2 text-sm text-cyber-muted mb-2">
              <Activity className="w-4 h-4 text-accent-600" />
              Active Investigations
            </div>
            <p className="text-3xl font-bold text-cyber-text">
              {incidents.filter((i) => i.status === 'Investigating').length}
            </p>
          </div>
        </div>
      </div>

      {/* Recent incidents table */}
      <div className="card p-5">
        <h2 className="font-semibold text-cyber-text mb-4">Recent Incidents</h2>
        <div className="overflow-x-auto -mx-5 px-5">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-cyber-muted border-b border-cyber-border">
                <th className="pb-3 pr-4 font-medium">Incident ID</th>
                <th className="pb-3 pr-4 font-medium">Risk</th>
                <th className="pb-3 pr-4 font-medium">Threat Type</th>
                <th className="pb-3 pr-4 font-medium hidden md:table-cell">Sender</th>
                <th className="pb-3 pr-4 font-medium hidden lg:table-cell">Subject</th>
                <th className="pb-3 pr-4 font-medium hidden lg:table-cell">Date/Time</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {incidents.slice(0, 8).map((inc) => (
                <tr key={inc.id} className="border-b border-cyber-border last:border-0 hover:bg-accent-50 transition-colors">
                  <td className="py-3 pr-4">
                    <Link to={`/investigator/incidents/${inc.id}`} className="font-mono text-accent-600 hover:text-accent-700 font-medium">
                      {inc.id}
                    </Link>
                  </td>
                  <td className="py-3 pr-4">
                    <span className={`badge ${getThreatLevelColor(inc.threatLevel)}`}>{inc.riskScore}</span>
                  </td>
                  <td className="py-3 pr-4 text-cyber-text">{inc.threatType}</td>
                  <td className="py-3 pr-4 text-cyber-muted hidden md:table-cell truncate max-w-[160px]">{inc.senderEmail}</td>
                  <td className="py-3 pr-4 text-cyber-muted hidden lg:table-cell truncate max-w-[200px]">{inc.subject}</td>
                  <td className="py-3 pr-4 text-cyber-muted hidden lg:table-cell whitespace-nowrap">
                    <span className="flex items-center gap-1 text-xs"><Clock className="w-3 h-3" />{inc.dateTime.split(' ')[0]}</span>
                  </td>
                  <td className="py-3">
                    <span className={`badge ${getStatusColor(inc.status)}`}>{inc.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
