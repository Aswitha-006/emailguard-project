import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { getIncidentById, Incident, IncidentStatus } from '@/data/mockData';
import { getThreatLevelColor, getStatusColor, getAuthResultColor, getUrlClassificationColor } from '@/utils/helpers';
import { RiskGauge, ProgressBar, Badge, Toast } from '@/components/ui/Primitives';
import {
  ArrowLeft,
  Mail,
  ShieldAlert,
  Brain,
  ShieldCheck,
  Link2,
  Globe,
  Network,
  UserCog,
  StickyNote,
  FileText,
  Crosshair,
  CheckCircle2,
  AlertTriangle,
  Eye,
  Lock,
  DollarSign,
  EyeOff,
} from 'lucide-react';

export default function IncidentDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const incident = id ? getIncidentById(id) : undefined;
  const [status, setStatus] = useState<IncidentStatus | undefined>(incident?.status);
  const [assigned, setAssigned] = useState(incident?.assignedInvestigator || null);
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [notes, setNotes] = useState(incident?.notes || []);
  const [noteText, setNoteText] = useState('');
  const [showNoteInput, setShowNoteInput] = useState(false);

  if (!incident) {
    return (
      <div className="text-center py-20">
        <p className="text-cyber-muted">Incident not found.</p>
        <Link to="/investigator/alerts" className="text-accent-600 hover:underline mt-2 inline-block">Back to Alerts</Link>
      </div>
    );
  }

  const fireToast = (msg: string) => {
    setToastMsg(msg);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2500);
  };

  const handleAssign = () => {
    setAssigned('You (Current User)');
    fireToast('Incident assigned to you');
  };

  const handleStatusChange = (newStatus: IncidentStatus) => {
    setStatus(newStatus);
    fireToast(`Incident marked as ${newStatus}`);
  };

  const handleAddNote = () => {
    if (!noteText.trim()) return;
    setNotes([...notes, { author: 'You', text: noteText, date: new Date().toISOString().split('T')[0] }]);
    setNoteText('');
    setShowNoteInput(false);
    fireToast('Note added');
  };

  const handleGenerateReport = () => fireToast('Report generated — check Reports page');
  const handleViewTrace = () => navigate(`/investigator/trace/${incident.id}`);

  return (
    <div className="space-y-6">
      {/* Back + header */}
      <div>
        <Link to="/investigator/alerts" className="text-sm text-cyber-muted hover:text-accent-600 mb-3 inline-flex items-center gap-1 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Alerts
        </Link>
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <h1 className="text-2xl font-bold text-cyber-text">{incident.id}</h1>
              <Badge className={getThreatLevelColor(incident.threatLevel)}>{incident.threatLevel}</Badge>
              <Badge className="bg-accent-50 text-accent-700 border border-accent-200">{incident.threatType}</Badge>
              <Badge className={getStatusColor(status || incident.status)}>{status || incident.status}</Badge>
            </div>
            <p className="text-cyber-muted">{incident.subject}</p>
          </div>
          <div className="flex items-center gap-2">
            <RiskGauge score={incident.riskScore} size="md" />
          </div>
        </div>
      </div>

      {/* Investigator Actions */}
      <div className="card p-4">
        <h2 className="text-sm font-semibold text-cyber-text mb-3">Investigator Actions</h2>
        <div className="flex flex-wrap gap-2">
          <button onClick={handleAssign} className="btn-secondary text-sm" disabled={!!assigned}>
            <UserCog className="w-4 h-4" />
            {assigned ? `Assigned: ${assigned}` : 'Assign to Me'}
          </button>
          <button onClick={() => handleStatusChange('Investigating')} className="btn-secondary text-sm">
            <Eye className="w-4 h-4" /> Mark Investigating
          </button>
          <button onClick={() => handleStatusChange('Resolved')} className="btn-secondary text-sm">
            <CheckCircle2 className="w-4 h-4" /> Mark Resolved
          </button>
          <button onClick={() => setShowNoteInput(!showNoteInput)} className="btn-secondary text-sm">
            <StickyNote className="w-4 h-4" /> Add Note
          </button>
          <button onClick={handleGenerateReport} className="btn-secondary text-sm">
            <FileText className="w-4 h-4" /> Generate Report
          </button>
          <button onClick={handleViewTrace} className="btn-primary text-sm">
            <Crosshair className="w-4 h-4" /> View Trace
          </button>
        </div>

        {showNoteInput && (
          <div className="mt-3 flex gap-2 animate-fade-in">
            <input
              type="text"
              value={noteText}
              onChange={(e) => setNoteText(e.target.value)}
              placeholder="Add investigation note..."
              className="input-field flex-1"
              onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
            />
            <button onClick={handleAddNote} className="btn-primary text-sm">Add</button>
          </div>
        )}

        {notes.length > 0 && (
          <div className="mt-3 space-y-2">
            {notes.map((note, i) => (
              <div key={i} className="bg-accent-50 rounded-lg p-3 text-sm">
                <p className="text-cyber-text">{note.text}</p>
                <p className="text-xs text-cyber-muted mt-1">— {note.author}, {note.date}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Email Information */}
      <Section icon={Mail} title="Email Information">
        <div className="grid md:grid-cols-2 gap-4">
          <InfoRow label="Sender Name" value={incident.senderName} />
          <InfoRow label="Sender Email" value={incident.senderEmail} mono />
          <InfoRow label="Recipient Email" value={incident.recipientEmail} mono />
          <InfoRow label="CC" value={incident.cc || '—'} mono />
          <InfoRow label="Reply-To" value={incident.replyTo || '—'} mono />
          <InfoRow label="Subject" value={incident.subject} />
          <InfoRow label="Date/Time" value={incident.dateTime} />
          <InfoRow label="Email ID" value={incident.emailId} mono />
        </div>
        {incident.attachments.length > 0 && (
          <div className="mt-4">
            <p className="text-sm font-medium text-cyber-text mb-2">Attachments</p>
            <div className="flex flex-wrap gap-2">
              {incident.attachments.map((att) => (
                <span key={att} className="badge bg-red-50 text-red-600 border border-red-200">
                  <AlertTriangle className="w-3 h-3" /> {att}
                </span>
              ))}
            </div>
          </div>
        )}
        <div className="mt-4">
          <p className="text-sm font-medium text-cyber-text mb-2">Email Body</p>
          <div className="bg-gray-50 rounded-xl p-4 text-sm text-cyber-text whitespace-pre-wrap font-mono leading-relaxed border border-cyber-border">
            {incident.emailBody}
          </div>
        </div>
      </Section>

      {/* Threat Detection */}
      <Section icon={ShieldAlert} title="Threat Detection">
        <div className="flex items-center gap-6 flex-wrap">
          <RiskGauge score={incident.riskScore} size="lg" />
          <div className="flex-1 min-w-[200px] space-y-3">
            <div>
              <p className="text-xs text-cyber-muted mb-1">Overall Risk Score</p>
              <p className="text-3xl font-bold text-cyber-text">{incident.riskScore}<span className="text-lg text-cyber-muted">/100</span></p>
            </div>
            <div>
              <p className="text-xs text-cyber-muted mb-1">Threat Level</p>
              <Badge className={getThreatLevelColor(incident.threatLevel)}>{incident.threatLevel}</Badge>
            </div>
            <div>
              <p className="text-xs text-cyber-muted mb-1">Classification</p>
              <Badge className="bg-accent-100 text-accent-700 border border-accent-200">{incident.threatType}</Badge>
            </div>
          </div>
        </div>
      </Section>

      {/* AI Analysis */}
      <Section icon={Brain} title="AI Analysis">
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-cyber-text">AI Confidence</span>
            <span className="text-sm font-bold text-accent-600">{incident.aiConfidence}%</span>
          </div>
          <ProgressBar value={incident.aiConfidence} color="bg-accent-500" />
        </div>

        <div className="bg-accent-50 rounded-xl p-4 mb-4 border border-accent-100">
          <p className="text-sm text-cyber-text italic leading-relaxed">«{incident.aiExplanation}»</p>
        </div>

        <p className="text-sm font-medium text-cyber-text mb-2">Detected Suspicious Behavior</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {incident.suspiciousBehavior.map((b) => (
            <span key={b} className="badge bg-orange-50 text-orange-700 border border-orange-200">{b}</span>
          ))}
          {incident.suspiciousBehavior.length === 0 && <span className="text-sm text-cyber-muted">No suspicious behavior detected.</span>}
        </div>

        <div className="grid sm:grid-cols-2 gap-3">
          <DetectionFlag icon={AlertTriangle} label="Urgency Detected" value={incident.urgencyDetected} />
          <DetectionFlag icon={DollarSign} label="Financial Request Detected" value={incident.financialRequest} />
          <DetectionFlag icon={UserCog} label="Impersonation Detected" value={incident.impersonationDetected} />
          <DetectionFlag icon={EyeOff} label="Secrecy/Manipulation Detected" value={incident.secrecyManipulation} />
        </div>

        {incident.suspiciousLanguage.length > 0 && (
          <div className="mt-4">
            <p className="text-sm font-medium text-cyber-text mb-2">Suspicious Language</p>
            <div className="flex flex-wrap gap-2">
              {incident.suspiciousLanguage.map((lang) => (
                <span key={lang} className="badge bg-amber-50 text-amber-700 border border-amber-200 font-mono">"{lang}"</span>
              ))}
            </div>
          </div>
        )}
      </Section>

      {/* Email Security Checks */}
      <Section icon={ShieldCheck} title="Email Security Checks">
        <div className="grid sm:grid-cols-3 gap-3 mb-4">
          {['SPF', 'DKIM', 'DMARC'].map((check) => {
            const val = incident[check.toLowerCase() as 'spf' | 'dkim' | 'dmarc'];
            return (
              <div key={check} className={`rounded-xl p-3 text-center border ${getAuthResultColor(val)}`}>
                <p className="text-xs mb-1">{check}</p>
                <p className="text-lg font-bold">{val}</p>
              </div>
            );
          })}
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <InfoRow label="Sender Domain" value={incident.senderDomain} mono />
          <InfoRow label="Reply-To Mismatch" value={incident.replyToMismatch ? 'Yes — Mismatch detected' : 'No mismatch'} />
          <InfoRow label="Display-Name Spoofing" value={incident.displayNameSpoofing ? 'Detected' : 'Not detected'} />
          <InfoRow label="Domain Similarity Score" value={`${incident.domainSimilarityScore}%`} />
        </div>
      </Section>

      {/* URL Analysis */}
      <Section icon={Link2} title="URL Analysis">
        {incident.urls.length === 0 ? (
          <p className="text-sm text-cyber-muted">No URLs found in this email.</p>
        ) : (
          <div className="space-y-3">
            {incident.urls.map((url, i) => (
              <div key={i} className="bg-gray-50 rounded-xl p-4 border border-cyber-border">
                <div className="flex items-center gap-2 mb-3">
                  <Globe className="w-4 h-4 text-cyber-muted" />
                  <span className="text-sm font-mono text-cyber-text break-all">{url.url}</span>
                  <span className={`badge ml-auto ${getUrlClassificationColor(url.classification)}`}>{url.classification}</span>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 text-sm">
                  <InfoRow label="Destination Domain" value={url.destinationDomain} mono />
                  <InfoRow label="Lookalike Domain" value={`${url.lookalikePercent}%`} />
                  <InfoRow label="Domain Reputation" value={url.domainReputation} />
                  <InfoRow label="Hosting Info" value={url.hostingInfo} />
                </div>
              </div>
            ))}
          </div>
        )}
      </Section>

      {/* IP / Header Information */}
      <Section icon={Network} title="IP / Header Information">
        <div className="grid md:grid-cols-2 gap-4">
          <InfoRow label="Sender IP" value={incident.headerInfo.senderIP} mono />
          <InfoRow label="Mail Relay" value={incident.headerInfo.mailRelay} mono />
          <InfoRow label="ASN / ISP" value={incident.headerInfo.asnIsp} />
          <InfoRow label="Hostname" value={incident.headerInfo.hostname} mono />
          <InfoRow label="IP Reputation" value={incident.headerInfo.ipReputation} />
          <div>
            <p className="text-xs text-cyber-muted mb-1">Received IPs</p>
            <div className="flex flex-wrap gap-1.5">
              {incident.headerInfo.receivedIPs.map((ip) => (
                <span key={ip} className="badge bg-gray-100 text-cyber-text border border-cyber-border font-mono">{ip}</span>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Risk Breakdown */}
      <Section icon={Activity} title="Risk Breakdown">
        <div className="space-y-4">
          {incident.riskBreakdown.map((item) => (
            <div key={item.category}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-cyber-text">{item.category}</span>
                <span className="text-sm font-bold text-cyber-text">{item.score}/25</span>
              </div>
              <ProgressBar value={item.score} max={25} />
              <p className="text-xs text-cyber-muted mt-1">{item.description}</p>
            </div>
          ))}
        </div>
      </Section>

      <Toast message={toastMsg} visible={showToast} />
    </div>
  );
}

function Section({ icon: Icon, title, children }: { icon: any; title: string; children: React.ReactNode }) {
  return (
    <div className="card p-5 animate-slide-up">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-accent-100 flex items-center justify-center">
          <Icon className="w-4 h-4 text-accent-600" />
        </div>
        <h2 className="font-semibold text-cyber-text">{title}</h2>
      </div>
      {children}
    </div>
  );
}

function InfoRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div>
      <p className="text-xs text-cyber-muted mb-1">{label}</p>
      <p className={`text-sm text-cyber-text ${mono ? 'font-mono break-all' : ''}`}>{value}</p>
    </div>
  );
}

function DetectionFlag({ icon: Icon, label, value }: { icon: any; label: string; value: boolean }) {
  return (
    <div className={`rounded-xl p-3 border flex items-center gap-3 ${value ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}>
      <Icon className={`w-4 h-4 ${value ? 'text-red-600' : 'text-green-600'}`} />
      <div className="flex-1">
        <p className="text-xs text-cyber-muted">{label}</p>
        <p className={`text-sm font-medium ${value ? 'text-red-700' : 'text-green-700'}`}>{value ? 'Yes' : 'No'}</p>
      </div>
    </div>
  );
}

function Activity(props: any) {
  return <ShieldAlert {...props} />;
}
