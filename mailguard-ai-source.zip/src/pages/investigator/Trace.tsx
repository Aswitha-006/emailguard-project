import { useParams, Link } from 'react-router-dom';
import { getIncidentById } from '@/data/mockData';
import { ArrowLeft, MapPin, Server, Network, Globe, Crosshair, ArrowRight } from 'lucide-react';

const stepIcons = [Server, Network, Server, Globe, MapPin];

export default function Trace() {
  const { id } = useParams();
  const incident = id ? getIncidentById(id) : undefined;

  if (!incident) {
    return (
      <div className="text-center py-20">
        <p className="text-cyber-muted">Incident not found.</p>
        <Link to="/investigator/alerts" className="text-accent-600 hover:underline mt-2 inline-block">Back to Alerts</Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <Link to={`/investigator/incidents/${incident.id}`} className="text-sm text-cyber-muted hover:text-accent-600 mb-3 inline-flex items-center gap-1 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Incident
        </Link>
        <h1 className="text-2xl font-bold text-cyber-text">Email Infrastructure Trace</h1>
        <p className="text-cyber-muted mt-1">{incident.id} — {incident.subject}</p>
      </div>

      {/* Disclaimer */}
      <div className="bg-accent-50 border border-accent-200 rounded-xl p-4 flex items-start gap-3">
        <Crosshair className="w-5 h-5 text-accent-600 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-medium text-cyber-text">IP Geolocation Estimate</p>
          <p className="text-xs text-cyber-muted mt-1">
            This trace shows the probable infrastructure location based on IP geolocation data. This is not an attacker location —
            it represents the hosting infrastructure that relayed the email.
          </p>
        </div>
      </div>

      {/* Trace path */}
      <div className="card p-6">
        <div className="space-y-0">
          {incident.traceNodes.map((node, i) => {
            const Icon = stepIcons[i] || MapPin;
            const isLast = i === incident.traceNodes.length - 1;
            return (
              <div key={i} className="flex gap-4 animate-slide-up" style={{ animationDelay: `${i * 100}ms` }}>
                {/* Left rail */}
                <div className="flex flex-col items-center">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                    isLast ? 'bg-accent-600 text-white shadow-lg' : 'bg-accent-100 text-accent-600'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  {!isLast && <div className="w-0.5 flex-1 bg-gradient-to-b from-accent-300 to-accent-100 min-h-[60px]" />}
                </div>

                {/* Content */}
                <div className={`flex-1 ${isLast ? 'pb-0' : 'pb-6'}`}>
                  <div className="card p-4 hover:border-accent-300 transition-all">
                    <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                      <h3 className="font-semibold text-cyber-text text-sm">{node.step}</h3>
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-accent-600" />
                        <span className="text-xs font-medium text-cyber-text">{node.city}, {node.country}</span>
                      </div>
                    </div>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                      <div>
                        <p className="text-xs text-cyber-muted">IP Address</p>
                        <p className="font-mono text-cyber-text">{node.ip}</p>
                      </div>
                      <div>
                        <p className="text-xs text-cyber-muted">Hostname</p>
                        <p className="font-mono text-cyber-text text-xs break-all">{node.hostname}</p>
                      </div>
                      <div>
                        <p className="text-xs text-cyber-muted">ISP / ASN</p>
                        <p className="text-cyber-text text-xs">{node.ispAsn}</p>
                      </div>
                      <div>
                        <p className="text-xs text-cyber-muted">Probable Infrastructure Location</p>
                        <p className="text-cyber-text">{node.city}, {node.country}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Summary */}
      <div className="card p-5">
        <h2 className="font-semibold text-cyber-text mb-3">Trace Summary</h2>
        <div className="flex items-center gap-2 flex-wrap text-sm">
          {incident.traceNodes.map((node, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="badge bg-accent-50 text-accent-700 border border-accent-200">{node.step}</span>
              {i < incident.traceNodes.length - 1 && <ArrowRight className="w-3 h-3 text-cyber-muted" />}
            </div>
          ))}
        </div>
        <div className="mt-4 grid sm:grid-cols-2 gap-3">
          <div className="bg-gray-50 rounded-xl p-3 border border-cyber-border">
            <p className="text-xs text-cyber-muted">Origin IP</p>
            <p className="font-mono text-sm text-cyber-text">{incident.headerInfo.senderIP}</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-3 border border-cyber-border">
            <p className="text-xs text-cyber-muted">IP Reputation</p>
            <p className="text-sm text-cyber-text">{incident.headerInfo.ipReputation}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
