import { useState } from 'react';
import { Link } from 'react-router-dom';
import { cases, getIncidentById, Case, CaseStatus } from '@/data/mockData';
import { getStatusColor, getThreatLevelColor } from '@/utils/helpers';
import { FolderKanban, ArrowRight, ChevronDown } from 'lucide-react';

const statusOptions: CaseStatus[] = ['New', 'Investigating', 'Escalated', 'Resolved'];

export default function Cases() {
  const [caseList, setCaseList] = useState<Case[]>(cases);
  const [openMenu, setOpenMenu] = useState<string | null>(null);

  const handleStatusChange = (caseId: string, newStatus: CaseStatus) => {
    setCaseList(caseList.map((c) => c.id === caseId ? { ...c, status: newStatus, lastUpdated: '2024-09-04' } : c));
    setOpenMenu(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-cyber-text">Cases</h1>
        <p className="text-cyber-muted mt-1">Manage investigation cases — update status inline</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statusOptions.map((s) => {
          const count = caseList.filter((c) => c.status === s).length;
          return (
            <div key={s} className="card p-4">
              <div className="flex items-center justify-between">
                <span className={`badge ${getStatusColor(s)}`}>{s}</span>
                <span className="text-2xl font-bold text-cyber-text">{count}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Cases table */}
      <div className="card p-5">
        <div className="overflow-x-auto -mx-5 px-5">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-cyber-muted border-b border-cyber-border">
                <th className="pb-3 pr-4 font-medium">Case ID</th>
                <th className="pb-3 pr-4 font-medium">Incident</th>
                <th className="pb-3 pr-4 font-medium">Priority</th>
                <th className="pb-3 pr-4 font-medium hidden md:table-cell">Investigator</th>
                <th className="pb-3 pr-4 font-medium">Status</th>
                <th className="pb-3 pr-4 font-medium hidden lg:table-cell">Created</th>
                <th className="pb-3 pr-4 font-medium hidden lg:table-cell">Updated</th>
              </tr>
            </thead>
            <tbody>
              {caseList.map((c) => {
                const inc = getIncidentById(c.incidentId);
                return (
                  <tr key={c.id} className="border-b border-cyber-border last:border-0 hover:bg-accent-50 transition-colors">
                    <td className="py-3 pr-4">
                      <span className="font-mono font-medium text-cyber-text">{c.id}</span>
                    </td>
                    <td className="py-3 pr-4">
                      <Link to={`/investigator/incidents/${c.incidentId}`} className="text-accent-600 hover:text-accent-700 font-mono text-xs">
                        {c.incidentId}
                      </Link>
                      {inc && <p className="text-xs text-cyber-muted truncate max-w-[180px] mt-0.5">{inc.subject}</p>}
                    </td>
                    <td className="py-3 pr-4">
                      <span className={`badge ${getThreatLevelColor(c.priority)}`}>{c.priority}</span>
                    </td>
                    <td className="py-3 pr-4 text-cyber-text hidden md:table-cell">{c.assignedInvestigator}</td>
                    <td className="py-3 pr-4">
                      <div className="relative">
                        <button
                          onClick={() => setOpenMenu(openMenu === c.id ? null : c.id)}
                          className={`badge ${getStatusColor(c.status)} cursor-pointer hover:opacity-80 transition-opacity flex items-center gap-1`}
                        >
                          {c.status}
                          <ChevronDown className="w-3 h-3" />
                        </button>
                        {openMenu === c.id && (
                          <div className="absolute top-full left-0 mt-1 bg-white border border-cyber-border rounded-xl shadow-lg z-10 min-w-[140px] py-1 animate-fade-in">
                            {statusOptions.map((s) => (
                              <button
                                key={s}
                                onClick={() => handleStatusChange(c.id, s)}
                                className="w-full text-left px-3 py-1.5 text-sm hover:bg-accent-50 transition-colors text-cyber-text"
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 pr-4 text-cyber-muted hidden lg:table-cell text-xs">{c.createdDate}</td>
                    <td className="py-3 pr-4 text-cyber-muted hidden lg:table-cell text-xs">{c.lastUpdated}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
