import { useState } from 'react';
import { Link } from 'react-router-dom';
import { incidents, Incident } from '@/data/mockData';
import { getThreatLevelColor, getStatusColor } from '@/utils/helpers';
import { Search, Filter, ArrowRight } from 'lucide-react';

type FilterType = 'All' | 'Critical' | 'High' | 'Medium' | 'Low' | 'Phishing' | 'BEC' | 'Impersonation' | 'Suspicious' | 'Resolved';

const filters: FilterType[] = ['All', 'Critical', 'High', 'Medium', 'Low', 'Phishing', 'BEC', 'Impersonation', 'Suspicious', 'Resolved'];

export default function Alerts() {
  const [activeFilter, setActiveFilter] = useState<FilterType>('All');
  const [search, setSearch] = useState('');

  const filtered = incidents.filter((inc) => {
    const matchesFilter =
      activeFilter === 'All' ||
      inc.threatLevel === activeFilter ||
      inc.threatType === activeFilter ||
      (activeFilter === 'Resolved' && inc.status === 'Resolved');
    const matchesSearch =
      !search ||
      inc.subject.toLowerCase().includes(search.toLowerCase()) ||
      inc.senderEmail.toLowerCase().includes(search.toLowerCase()) ||
      inc.id.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-cyber-text">Alerts</h1>
        <p className="text-cyber-muted mt-1">All detected email threats — click any alert to investigate</p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyber-muted" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by subject, sender, or incident ID..."
          className="input-field pl-11"
        />
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="w-4 h-4 text-cyber-muted" />
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setActiveFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              activeFilter === f
                ? 'bg-accent-600 text-white'
                : 'bg-white text-cyber-muted border border-cyber-border hover:border-accent-300 hover:text-accent-600'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Alert cards */}
      <div className="grid gap-3">
        {filtered.length === 0 ? (
          <div className="card p-8 text-center text-cyber-muted">No alerts match your filters.</div>
        ) : (
          filtered.map((inc) => <AlertCard key={inc.id} incident={inc} />)
        )}
      </div>
    </div>
  );
}

function AlertCard({ incident }: { incident: Incident }) {
  return (
    <Link
      to={`/investigator/incidents/${incident.id}`}
      className="card p-4 hover:border-accent-300 transition-all group block"
    >
      <div className="flex items-start gap-4">
        {/* Risk score */}
        <div className="shrink-0 text-center">
          <div className={`w-14 h-14 rounded-xl flex flex-col items-center justify-center ${
            incident.riskScore >= 80 ? 'bg-red-50 text-red-600' :
            incident.riskScore >= 60 ? 'bg-orange-50 text-orange-600' :
            incident.riskScore >= 40 ? 'bg-amber-50 text-amber-600' : 'bg-green-50 text-green-600'
          }`}>
            <span className="text-xl font-bold">{incident.riskScore}</span>
            <span className="text-[9px]">RISK</span>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="text-xs font-mono text-cyber-muted">{incident.id}</span>
            <span className={`badge ${getThreatLevelColor(incident.threatLevel)}`}>{incident.threatLevel}</span>
            <span className="badge bg-accent-50 text-accent-700 border border-accent-200">{incident.threatType}</span>
            <span className={`badge ${getStatusColor(incident.status)}`}>{incident.status}</span>
          </div>
          <p className="text-sm font-medium text-cyber-text truncate">{incident.subject}</p>
          <div className="flex items-center gap-2 text-xs text-cyber-muted mt-1">
            <span className="truncate">{incident.senderEmail}</span>
            <span>→</span>
            <span className="truncate">{incident.recipientEmail}</span>
          </div>
          <p className="text-xs text-cyber-muted mt-1.5 line-clamp-1 italic">"{incident.aiExplanation}"</p>
          <p className="text-[11px] text-cyber-muted mt-1">{incident.dateTime}</p>
        </div>

        <ArrowRight className="w-5 h-5 text-cyber-muted group-hover:text-accent-600 transition-colors shrink-0 mt-2" />
      </div>
    </Link>
  );
}
