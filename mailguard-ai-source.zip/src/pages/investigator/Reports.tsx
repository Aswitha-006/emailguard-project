import { useState } from 'react';
import { reports, getIncidentById, getCaseById, Report } from '@/data/mockData';
import { getThreatLevelColor, getStatusColor } from '@/utils/helpers';
import { FileText, Download, Eye, ArrowLeft, X } from 'lucide-react';
import { Toast } from '@/components/ui/Primitives';

export default function Reports() {
  const [selected, setSelected] = useState<Report | null>(null);
  const [showToast, setShowToast] = useState(false);

  const fireToast = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2500);
  };

  if (selected) {
    const inc = getIncidentById(selected.incidentId);
    const cs = getCaseById(selected.caseId);

    const reportSections = [
      { title: '1. Case Summary', content: `Case ${selected.caseId} was opened in response to incident ${selected.incidentId}. The incident involves a ${inc?.threatType} threat with a risk score of ${inc?.riskScore}/100, classified as ${inc?.threatLevel} severity. The case is currently ${cs?.status}.` },
      { title: '2. Email Metadata', content: `Sender: ${inc?.senderName} <${inc?.senderEmail}>\nRecipient: ${inc?.recipientEmail}\nCC: ${inc?.cc || 'None'}\nReply-To: ${inc?.replyTo || 'None'}\nSubject: ${inc?.subject}\nDate/Time: ${inc?.dateTime}\nEmail ID: ${inc?.emailId}\nAttachments: ${inc?.attachments.join(', ') || 'None'}` },
      { title: '3. Risk & Classification', content: `Overall Risk Score: ${inc?.riskScore}/100\nThreat Level: ${inc?.threatLevel}\nClassification: ${inc?.threatType}` },
      { title: '4. AI Explanation', content: inc?.aiExplanation || '' },
      { title: '5. SPF/DKIM/DMARC Results', content: `SPF: ${inc?.spf}\nDKIM: ${inc?.dkim}\nDMARC: ${inc?.dmarc}\nSender Domain: ${inc?.senderDomain}\nReply-To Mismatch: ${inc?.replyToMismatch ? 'Yes' : 'No'}\nDisplay-Name Spoofing: ${inc?.displayNameSpoofing ? 'Yes' : 'No'}\nDomain Similarity Score: ${inc?.domainSimilarityScore}%` },
      { title: '6. Header & Relay Analysis', content: `Sender IP: ${inc?.headerInfo.senderIP}\nMail Relay: ${inc?.headerInfo.mailRelay}\nASN/ISP: ${inc?.headerInfo.asnIsp}\nHostname: ${inc?.headerInfo.hostname}\nIP Reputation: ${inc?.headerInfo.ipReputation}\nReceived IPs: ${inc?.headerInfo.receivedIPs.join(', ')}` },
      { title: '7. URLs / Domains / IPs', content: inc?.urls.length ? inc.urls.map(u => `URL: ${u.url}\nDomain: ${u.destinationDomain}\nClassification: ${u.classification}\nLookalike: ${u.lookalikePercent}%\nReputation: ${u.domainReputation}\nHosting: ${u.hostingInfo}`).join('\n\n') : 'No URLs found in this email.' },
      { title: '8. Infrastructure / Geolocation', content: inc?.traceNodes.map(t => `${t.step}: ${t.ip} (${t.hostname})\nISP/ASN: ${t.ispAsn}\nProbable Infrastructure Location: ${t.city}, ${t.country}`).join('\n\n') || '' },
      { title: '9. Related Incidents / Campaign', content: 'This incident is linked to a broader campaign targeting the organization with similar threat patterns. See campaign analysis for correlation details.' },
      { title: '10. Attribution Confidence', content: `Attribution confidence: ${selected.attributionConfidence}%\nBased on infrastructure analysis, domain registration patterns, and AI behavioral analysis.` },
      { title: '11. Recommended Actions', content: `1. Block sender domain and IP at the email gateway\n2. Remove delivered messages from affected mailboxes\n3. Educate users about the specific threat pattern\n4. Monitor for similar senders or domains\n5. ${inc?.recommendedAction}` },
      { title: '12. Evidence & Audit Details', content: `Report ID: ${selected.id}\nGenerated: ${selected.generatedDate}\nCase ID: ${selected.caseId}\nIncident ID: ${selected.incidentId}\nEvidence preserved: Email headers, body, attachments, URL analysis, IP trace data\nAudit trail: All investigator actions logged` },
    ];

    return (
      <div className="space-y-6">
        <div>
          <button onClick={() => setSelected(null)} className="text-sm text-cyber-muted hover:text-accent-600 mb-3 inline-flex items-center gap-1 transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Reports
          </button>
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-2xl font-bold text-cyber-text">{selected.title}</h1>
              <p className="text-cyber-muted mt-1">{selected.id} — Generated {selected.generatedDate}</p>
            </div>
            <button onClick={fireToast} className="btn-primary">
              <Download className="w-4 h-4" /> Export Report
            </button>
          </div>
        </div>

        <div className="card p-4">
          <div className="flex items-center gap-4 flex-wrap text-sm">
            <div><span className="text-cyber-muted">Case:</span> <span className="font-mono text-cyber-text">{selected.caseId}</span></div>
            <div><span className="text-cyber-muted">Incident:</span> <span className="font-mono text-cyber-text">{selected.incidentId}</span></div>
            {inc && <span className={`badge ${getThreatLevelColor(inc.threatLevel)}`}>{inc.threatLevel}</span>}
            {inc && <span className={`badge ${getStatusColor(inc.status)}`}>{inc.status}</span>}
            <div><span className="text-cyber-muted">Attribution:</span> <span className="font-bold text-accent-600">{selected.attributionConfidence}%</span></div>
          </div>
        </div>

        <div className="space-y-3">
          {reportSections.map((section) => (
            <div key={section.title} className="card p-5">
              <h2 className="font-semibold text-cyber-text mb-2">{section.title}</h2>
              <div className="text-sm text-cyber-text whitespace-pre-wrap leading-relaxed">{section.content}</div>
            </div>
          ))}
        </div>

        <Toast message="Report exported (demo)" visible={showToast} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-cyber-text">Reports</h1>
        <p className="text-cyber-muted mt-1">Generated forensic reports — click to view full report</p>
      </div>

      <div className="grid gap-3">
        {reports.map((rpt) => {
          const inc = getIncidentById(rpt.incidentId);
          return (
            <div key={rpt.id} className="card p-4 hover:border-accent-300 transition-all">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 bg-accent-100 rounded-xl flex items-center justify-center shrink-0">
                  <FileText className="w-5 h-5 text-accent-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="font-mono text-xs text-cyber-muted">{rpt.id}</span>
                    {inc && <span className={`badge ${getThreatLevelColor(inc.threatLevel)}`}>{inc.threatLevel}</span>}
                  </div>
                  <h3 className="font-medium text-cyber-text">{rpt.title}</h3>
                  <div className="flex items-center gap-3 mt-1 text-xs text-cyber-muted flex-wrap">
                    <span>Case: {rpt.caseId}</span>
                    <span>Incident: {rpt.incidentId}</span>
                    <span>Generated: {rpt.generatedDate}</span>
                    <span>Attribution: <strong className="text-accent-600">{rpt.attributionConfidence}%</strong></span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={() => setSelected(rpt)} className="btn-secondary text-sm">
                    <Eye className="w-4 h-4" /> View
                  </button>
                  <button onClick={fireToast} className="btn-ghost text-sm">
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <Toast message="Report exported (demo)" visible={showToast} />
    </div>
  );
}
