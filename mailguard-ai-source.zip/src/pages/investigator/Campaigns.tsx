import { useState } from 'react';
import { Link } from 'react-router-dom';
import { campaigns, getIncidentById, Campaign } from '@/data/mockData';
import { getThreatLevelColor, getStatusColor } from '@/utils/helpers';
import { Crosshair, ArrowLeft, Calendar, Link2, Mail, ArrowRight } from 'lucide-react';

export default function Campaigns() {
  const [selected, setSelected] = useState<Campaign | null>(null);

  if (selected) {
    const relatedIncidents = selected.incidentIds.map((id) => getIncidentById(id)).filter(Boolean);

    return (
      <div className="space-y-6">
        <div>
          <button onClick={() => setSelected(null)} className="text-sm text-cyber-muted hover:text-accent-600 mb-3 inline-flex items-center gap-1 transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back to Campaigns
          </button>
          <div className="flex items-center gap-2 flex-wrap mb-2">
            <span className="font-mono text-accent-600 font-medium">{selected.id}</span>
            <span className={`badge ${getThreatLevelColor(selected.severity)}`}>{selected.severity}</span>
          </div>
          <h1 className="text-2xl font-bold text-cyber-text">{selected.name}</h1>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="card p-4">
            <p className="text-xs text-cyber-muted mb-1">Related Incidents</p>
            <p className="text-2xl font-bold text-cyber-text">{selected.incidentIds.length}</p>
          </div>
          <div className="card p-4">
            <p className="text-xs text-cyber-muted mb-1">Common Sender/Domain</p>
            <p className="text-sm font-medium text-cyber-text">{selected.commonSenderDomain}</p>
          </div>
          <div className="card p-4">
            <p className="text-xs text-cyber-muted mb-1">First Detected</p>
            <p className="text-sm font-medium text-cyber-text flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{selected.firstDetected}</p>
          </div>
          <div className="card p-4">
            <p className="text-xs text-cyber-muted mb-1">Last Detected</p>
            <p className="text-sm font-medium text-cyber-text flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{selected.lastDetected}</p>
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-2 mb-3">
            <Link2 className="w-4 h-4 text-cyber-muted" />
            <p className="text-sm font-medium text-cyber-text">Common URL Pattern</p>
          </div>
          <p className="text-sm text-cyber-muted">{selected.commonUrl}</p>
        </div>

        <div className="card p-5">
          <h2 className="font-semibold text-cyber-text mb-4">Related Incidents</h2>
          <div className="space-y-2">
            {relatedIncidents.map((inc) => inc && (
              <Link
                key={inc.id}
                to={`/investigator/incidents/${inc.id}`}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-accent-50 transition-all group border border-transparent hover:border-accent-200"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono text-cyber-muted">{inc.id}</span>
                    <span className={`badge ${getThreatLevelColor(inc.threatLevel)}`}>{inc.threatLevel}</span>
                    <span className={`badge ${getStatusColor(inc.status)}`}>{inc.status}</span>
                  </div>
                  <p className="text-sm font-medium text-cyber-text truncate">{inc.subject}</p>
                  <p className="text-xs text-cyber-muted truncate">{inc.senderEmail}</p>
                </div>
                <div className="text-right shrink-0">
                  <div className={`text-lg font-bold ${inc.riskScore >= 80 ? 'text-red-600' : 'text-orange-600'}`}>{inc.riskScore}</div>
                </div>
                <ArrowRight className="w-4 h-4 text-cyber-muted group-hover:text-accent-600 transition-colors" />
              </Link>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-cyber-text">Campaigns</h1>
        <p className="text-cyber-muted mt-1">Groups of related email threats — click to view details</p>
      </div>

      <div className="grid gap-4">
        {campaigns.map((camp) => {
          const incs = camp.incidentIds.map((id) => getIncidentById(id)).filter(Boolean);
          const avgRisk = incs.length > 0 ? Math.round(incs.reduce((s, i) => s + (i?.riskScore || 0), 0) / incs.length) : 0;
          return (
            <button
              key={camp.id}
              onClick={() => setSelected(camp)}
              className="card p-5 text-left hover:border-accent-300 transition-all group w-full"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center shrink-0">
                  <Crosshair className="w-6 h-6 text-accent-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="font-mono text-xs text-accent-600 font-medium">{camp.id}</span>
                    <span className={`badge ${getThreatLevelColor(camp.severity)}`}>{camp.severity}</span>
                  </div>
                  <h3 className="font-semibold text-cyber-text">{camp.name}</h3>
                  <div className="flex items-center gap-4 mt-2 text-xs text-cyber-muted flex-wrap">
                    <span className="flex items-center gap-1"><Mail className="w-3.5 h-3.5" /> {camp.incidentIds.length} incidents</span>
                    <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {camp.firstDetected} → {camp.lastDetected}</span>
                    <span>Avg risk: <strong className="text-cyber-text">{avgRisk}</strong></span>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 text-cyber-muted group-hover:text-accent-600 transition-colors shrink-0" />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
