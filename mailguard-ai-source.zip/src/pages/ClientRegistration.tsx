import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import {
  ShieldCheck,
  ArrowLeft,
  ArrowRight,
  Mail,
  KeyRound,
  Building2,
  MapPin,
  Phone,
  Briefcase,
  Users,
  CreditCard,
  Calendar,
  CheckCircle2,
  Loader2,
} from 'lucide-react';

const subscriptionPlans = [
  { value: 'Starter', label: 'Starter', price: '$29/mo', desc: 'Up to 50 emails/day' },
  { value: 'Professional', label: 'Professional', price: '$99/mo', desc: 'Up to 500 emails/day' },
  { value: 'Enterprise', label: 'Enterprise', price: 'Custom', desc: 'Unlimited volume' },
];

const billingCycles = ['Monthly', 'Annual'];

const orgSizes = ['1-10', '11-50', '51-200', '201-500', '500+'];

export default function ClientRegistration() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [form, setForm] = useState({
    email: '',
    gmailAppPassword: '',
    orgName: '',
    orgAddress: '',
    orgCountry: '',
    orgPhone: '',
    orgIndustry: '',
    orgSize: '',
    subscriptionPlan: 'Starter',
    billingCycle: 'Monthly',
    seats: 1,
  });

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const update = (key: string, value: string | number) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!form.email || !form.gmailAppPassword || !form.orgName) {
      setError('Please fill in email, Gmail app password, and organization name.');
      return;
    }

    if (form.gmailAppPassword.length < 8) {
      setError('Gmail app password should be at least 8 characters.');
      return;
    }

    if (form.seats < 1) {
      setError('Number of seats must be at least 1.');
      return;
    }

    setLoading(true);

    try {
      const { error: insertError } = await supabase.from('client_registrations').insert({
        email: form.email,
        gmail_app_password: form.gmailAppPassword,
        org_name: form.orgName,
        org_address: form.orgAddress || null,
        org_country: form.orgCountry || null,
        org_phone: form.orgPhone || null,
        org_industry: form.orgIndustry || null,
        org_size: form.orgSize || null,
        subscription_plan: form.subscriptionPlan,
        billing_cycle: form.billingCycle,
        seats: form.seats,
        subscription_status: 'active',
        subscription_start: new Date().toISOString().split('T')[0],
      });

      if (insertError) throw insertError;

      setSuccess(true);
      setTimeout(() => {
        login('client', form.email, undefined, form.orgName);
        navigate('/client');
      }, 1800);
    } catch (err: any) {
      setError(err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cyber-bg p-6">
        <div className="w-full max-w-md text-center animate-slide-up">
          <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-cyber-text">Registration Successful</h2>
          <p className="text-cyber-muted mt-2">
            Your organization <strong className="text-cyber-text">{form.orgName}</strong> has been registered with the{' '}
            <strong className="text-cyber-text">{form.subscriptionPlan}</strong> plan. Redirecting to your dashboard...
          </p>
          <div className="flex justify-center mt-6">
            <Loader2 className="w-6 h-6 text-accent-600 animate-spin" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Left side — branding (same as Login) */}
      <div className="hidden lg:flex lg:w-1/2 bg-cyber-sidebar relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-72 h-72 bg-accent-500 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-accent-700 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 flex flex-col justify-between p-12 text-white">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-accent-600 rounded-xl flex items-center justify-center shadow-lg">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">MailGuard AI</h1>
              <p className="text-xs text-white/60">Email Threat Detection & Investigation</p>
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="text-4xl font-bold leading-tight">
              Register Your<br />Organization
            </h2>
            <p className="text-white/70 text-lg leading-relaxed">
              Sign up your organization to start protecting your inbox from phishing, BEC, and impersonation attacks.
            </p>
            <div className="space-y-3 pt-4">
              {[
                'Choose your subscription plan',
                'Connect your Gmail via IMAP for email scanning',
                'Get protected in minutes',
              ].map((feat) => (
                <div key={feat} className="flex items-center gap-3 text-white/80">
                  <div className="w-5 h-5 rounded-full bg-accent-600/30 border border-accent-500/50 flex items-center justify-center">
                    <div className="w-1.5 h-1.5 bg-accent-400 rounded-full" />
                  </div>
                  <span className="text-sm">{feat}</span>
                </div>
              ))}
            </div>
          </div>

          <p className="text-white/40 text-xs">© 2024 MailGuard AI — Frontend Prototype</p>
        </div>
      </div>

      {/* Right side — registration form */}
      <div className="flex-1 flex items-start lg:items-center justify-center p-6 bg-cyber-bg overflow-y-auto">
        <div className="w-full max-w-md animate-slide-up py-8">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-3 mb-6 justify-center">
            <div className="w-10 h-10 bg-accent-600 rounded-xl flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-lg font-bold text-cyber-text">MailGuard AI</h1>
          </div>

          <button
            onClick={() => navigate('/')}
            className="text-sm text-cyber-muted hover:text-accent-600 mb-4 inline-flex items-center gap-1 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to login
          </button>

          <h2 className="text-2xl font-bold text-cyber-text">Client Registration</h2>
          <p className="text-cyber-muted mt-1 mb-6">Register your organization and choose a subscription plan</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Account Credentials */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-accent-700 uppercase tracking-wide">Account Credentials</h3>

              <div>
                <label className="text-sm font-medium text-cyber-text mb-1.5 block">Email ID</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyber-muted" />
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => update('email', e.target.value)}
                    placeholder="admin@yourcompany.com"
                    className="input-field pl-11"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-cyber-text mb-1.5 block">
                  Gmail App Password
                </label>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyber-muted" />
                  <input
                    type="password"
                    value={form.gmailAppPassword}
                    onChange={(e) => update('gmailAppPassword', e.target.value)}
                    placeholder="16-character Google app password"
                    className="input-field pl-11 font-mono"
                  />
                </div>
                <p className="text-xs text-cyber-muted mt-1.5">
                  Your Gmail app password is used for IMAP email access. Generate one in your Google Account under Security &gt; App passwords. No Google Cloud or Chrome extension required — we connect via IMAP only.
                </p>
              </div>
            </div>

            {/* Organization Details */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-accent-700 uppercase tracking-wide">Organization Details</h3>

              <div>
                <label className="text-sm font-medium text-cyber-text mb-1.5 block">Organization Name</label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyber-muted" />
                  <input
                    type="text"
                    value={form.orgName}
                    onChange={(e) => update('orgName', e.target.value)}
                    placeholder="Acme Corp"
                    className="input-field pl-11"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-cyber-text mb-1.5 block">Address</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyber-muted" />
                  <input
                    type="text"
                    value={form.orgAddress}
                    onChange={(e) => update('orgAddress', e.target.value)}
                    placeholder="123 Main St, New York, NY 10001"
                    className="input-field pl-11"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-cyber-text mb-1.5 block">Country</label>
                  <input
                    type="text"
                    value={form.orgCountry}
                    onChange={(e) => update('orgCountry', e.target.value)}
                    placeholder="United States"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-cyber-text mb-1.5 block">Phone</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyber-muted" />
                    <input
                      type="tel"
                      value={form.orgPhone}
                      onChange={(e) => update('orgPhone', e.target.value)}
                      placeholder="+1 (555) 000-0000"
                      className="input-field pl-10"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium text-cyber-text mb-1.5 block">Industry</label>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyber-muted" />
                    <input
                      type="text"
                      value={form.orgIndustry}
                      onChange={(e) => update('orgIndustry', e.target.value)}
                      placeholder="Finance"
                      className="input-field pl-10"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-cyber-text mb-1.5 block">Org Size</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyber-muted" />
                    <select
                      value={form.orgSize}
                      onChange={(e) => update('orgSize', e.target.value)}
                      className="input-field pl-10 appearance-none"
                    >
                      <option value="">Select...</option>
                      {orgSizes.map((s) => (
                        <option key={s} value={s}>{s} employees</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Subscription Details */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-accent-700 uppercase tracking-wide">Subscription Plan</h3>

              <div className="space-y-2">
                {subscriptionPlans.map((plan) => (
                  <button
                    key={plan.value}
                    type="button"
                    onClick={() => update('subscriptionPlan', plan.value)}
                    className={`w-full p-3.5 rounded-xl border text-left transition-all ${
                      form.subscriptionPlan === plan.value
                        ? 'border-accent-500 bg-accent-50 ring-2 ring-accent-100'
                        : 'border-cyber-border bg-white hover:border-accent-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <CreditCard className={`w-4 h-4 ${form.subscriptionPlan === plan.value ? 'text-accent-600' : 'text-cyber-muted'}`} />
                        <div>
                          <span className="text-sm font-medium text-cyber-text">{plan.label}</span>
                          <span className="text-xs text-cyber-muted ml-2">{plan.desc}</span>
                        </div>
                      </div>
                      <span className="text-sm font-semibold text-accent-600">{plan.price}</span>
                    </div>
                  </button>
                ))}
              </div>

              <div>
                <label className="text-sm font-medium text-cyber-text mb-1.5 block">Billing Cycle</label>
                <div className="flex gap-2">
                  {billingCycles.map((cycle) => (
                    <button
                      key={cycle}
                      type="button"
                      onClick={() => update('billingCycle', cycle)}
                      className={`flex-1 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                        form.billingCycle === cycle
                          ? 'border-accent-500 bg-accent-50 text-accent-700'
                          : 'border-cyber-border bg-white text-cyber-muted hover:border-accent-300'
                      }`}
                    >
                      {cycle}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-cyber-text mb-1.5 block">Number of Seats</label>
                <div className="relative">
                  <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyber-muted" />
                  <input
                    type="number"
                    min={1}
                    value={form.seats}
                    onChange={(e) => update('seats', parseInt(e.target.value) || 1)}
                    className="input-field pl-10"
                  />
                </div>
              </div>

              <div className="bg-accent-50 rounded-xl p-3 border border-accent-100 flex items-center gap-2 text-xs text-cyber-muted">
                <Calendar className="w-4 h-4 text-accent-600 shrink-0" />
                Subscription starts today. You will be billed {form.billingCycle.toLowerCase()} for {form.seats} seat{form.seats > 1 ? 's' : ''} on the {form.subscriptionPlan} plan.
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-2.5 rounded-xl">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Registering...
                </>
              ) : (
                <>
                  Register Organization
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
