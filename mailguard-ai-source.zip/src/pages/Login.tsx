import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { ShieldCheck, Search, Building2, Lock, Mail, KeyRound, ArrowRight, MailCheck, Download } from 'lucide-react';

export default function Login() {
  const [role, setRole] = useState<'investigator' | 'client' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mfa, setMfa] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Please fill in all required fields.');
      return;
    }

    if (role === 'investigator') {
      if (mfa.length !== 6) {
        setError('Please enter the 6-digit MFA code.');
        return;
      }
      login('investigator', email);
      navigate('/investigator');
    } else if (role === 'client') {
      login('client', email);
      navigate('/client');
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side — branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-cyber-sidebar relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-72 h-72 bg-accent-500 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-accent-700 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 flex flex-col justify-between p-12 text-white">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-accent-600 rounded-xl flex items-center justify-center shadow-lg">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">MailGuard AI</h1>
              <p className="text-xs text-white/60">Email Threat Detection & Investigation</p>
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="text-4xl font-bold leading-tight">
              AI-Powered Email<br />Threat Detection Platform
            </h2>
            <p className="text-white/70 text-lg leading-relaxed">
              Detect, investigate, and respond to phishing, BEC, and impersonation attacks with AI-driven analysis.
            </p>
            <div className="space-y-3 pt-4">
              {[
                'Real-time threat detection with AI analysis',
                'Deep email header & infrastructure tracing',
                'Forensic reporting & campaign correlation',
              ].map((feat) => (
                <div key={feat} className="flex items-center gap-3 text-white/80">
                  <div className="w-5 h-5 rounded-full bg-accent-600/30 border border-accent-500/50 flex items-center justify-center">
                    <div className="w-1.5 h-1.5 bg-accent-400 rounded-full" />
                  </div>
                  <span className="text-sm">{feat}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <a
              href="/mailguard-ai-source.zip"
              download
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-accent-600 text-white text-sm font-medium hover:bg-accent-700 transition-all shadow-lg"
            >
              <Download className="w-4 h-4" />
              Download Source Code (.zip)
            </a>
            <p className="text-white/40 text-xs">© 2024 MailGuard AI — Frontend Prototype</p>
          </div>
        </div>
      </div>

      {/* Right side — login form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-cyber-bg">
        <div className="w-full max-w-md animate-slide-up">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
            <div className="w-10 h-10 bg-accent-600 rounded-xl flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-lg font-bold text-cyber-text">MailGuard AI</h1>
          </div>

          {!role ? (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-cyber-text">Welcome</h2>
                <p className="text-cyber-muted mt-1">Select your role to continue</p>
              </div>

              <button
                onClick={() => setRole('investigator')}
                className="w-full card p-6 text-left hover:border-accent-300 hover:shadow-md transition-all group"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center group-hover:bg-accent-600 transition-colors">
                    <Search className="w-6 h-6 text-accent-600 group-hover:text-white transition-colors" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-cyber-text text-lg">Investigator</h3>
                    <p className="text-sm text-cyber-muted mt-1">
                      Full threat investigation dashboard with forensic tools, trace analysis, and case management.
                    </p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-cyber-muted group-hover:text-accent-600 transition-colors" />
                </div>
              </button>

              <button
                onClick={() => setRole('client')}
                className="w-full card p-6 text-left hover:border-accent-300 hover:shadow-md transition-all group"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center group-hover:bg-accent-600 transition-colors">
                    <Building2 className="w-6 h-6 text-accent-600 group-hover:text-white transition-colors" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-cyber-text text-lg">Client</h3>
                    <p className="text-sm text-cyber-muted mt-1">
                      Simple security overview showing your organization's email protection status and incidents.
                    </p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-cyber-muted group-hover:text-accent-600 transition-colors" />
                </div>
              </button>

              <div className="text-center text-sm text-cyber-muted pt-2">
                New organization?{' '}
                <button
                  type="button"
                  onClick={() => navigate('/register')}
                  className="text-accent-600 hover:text-accent-700 font-semibold underline underline-offset-2"
                >
                  Register your organization here
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <button
                  onClick={() => { setRole(null); setError(''); }}
                  className="text-sm text-cyber-muted hover:text-accent-600 mb-4 transition-colors"
                >
                  ← Back to role selection
                </button>
                <h2 className="text-2xl font-bold text-cyber-text">
                  {role === 'investigator' ? 'Investigator Login' : 'Client Login'}
                </h2>
                <p className="text-cyber-muted mt-1">
                  {role === 'investigator'
                    ? 'Enter your credentials and MFA code'
                    : 'Enter your company credentials'}
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-cyber-text mb-1.5 block">
                    {role === 'investigator' ? 'Investigator ID / Work Email' : 'Company Email'}
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyber-muted" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder={role === 'investigator' ? 'investigator@mailguard.ai' : 'you@acmecorp.com'}
                      className="input-field pl-11"
                      autoFocus
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-cyber-text mb-1.5 block">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyber-muted" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="input-field pl-11"
                    />
                  </div>
                </div>

                {role === 'investigator' && (
                  <div className="animate-fade-in">
                    <label className="text-sm font-medium text-cyber-text mb-1.5 block">6-digit MFA Code</label>
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-cyber-muted" />
                      <input
                        type="text"
                        value={mfa}
                        onChange={(e) => setMfa(e.target.value.replace(/\D/g, '').slice(0, 6))}
                        placeholder="123456"
                        maxLength={6}
                        className="input-field pl-11 tracking-[0.3em] font-mono"
                      />
                    </div>
                  </div>
                )}

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-2.5 rounded-xl">
                    {error}
                  </div>
                )}

                <button type="submit" className="btn-primary w-full">
                  Sign In
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {role === 'client' && (
                <>
                  <div className="flex items-center gap-2 text-xs text-cyber-muted bg-accent-50 px-4 py-3 rounded-xl">
                    <MailCheck className="w-4 h-4 text-accent-600" />
                    Use any email containing "acmecorp" or "globex" to see incidents.
                  </div>
                  <div className="text-center text-sm text-cyber-muted">
                    Don't have an account?{' '}
                    <button
                      type="button"
                      onClick={() => navigate('/register')}
                      className="text-accent-600 hover:text-accent-700 font-medium"
                    >
                      Register your organization
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
